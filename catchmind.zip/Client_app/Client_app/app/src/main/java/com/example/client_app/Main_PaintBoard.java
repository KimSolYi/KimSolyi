package com.example.morprubins;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.EmbossMaskFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Path.Direction;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.util.Log;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

public class Main_PaintBoard extends View {
    static Bitmap mBitmap = null;
    private Bitmap mBackBitmap = null;
    static Canvas mCanvas = null;

    static Path mPath;

    static Paint mBitmapPaint; // 완전 초기 비트맵 paint
    static Paint mPaint;
    static Paint mPaint1;
    int count=0, count1=0, count2=0;
    static int mMode = 0;  // 0 : draw, 1 : clear

    static int input_color = Color.RED; // 기본색.

    private static float stroke = 10; // 굵기.

    private int baseWidth, baseHeight; // 기본 Draw화면 너비, 높이

    private ImageView backImage = null;
    MotionEvent event;

    // 펜 스타일 종류 -------------------------------------------------------------------------------
    static EmbossMaskFilter filter0 = new EmbossMaskFilter(new float[]{0, 0, 0}, 0.5f, 0, 0); // 일반모드
    static EmbossMaskFilter filter1 = new EmbossMaskFilter(new float[]{2, 2, 2}, 0.1f, 1, 10); // neon
    static EmbossMaskFilter filter2 = new EmbossMaskFilter(new float[]{2, 2, 10}, 0.5f, 1, 10); // neon
    static BlurMaskFilter filter3 = new BlurMaskFilter(10, BlurMaskFilter.Blur.SOLID); // spray1
    static BlurMaskFilter filter4 = new BlurMaskFilter(10, BlurMaskFilter.Blur.OUTER); // spray2 (out_spray)

    // static int toX, toY;

    // 임의 View로 생성
    public Main_PaintBoard(Context context, AttributeSet attrs) {
        super(context, attrs);

        // 화면의 크기 알아내는 법 -------------------------------------------------------------------
        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        Display display = wm.getDefaultDisplay();
        baseWidth = display.getWidth();
        baseHeight = display.getHeight();

        // 화면의 크기의 비트맵 생성 -----------------------------------------------------------------
        mBitmap = Bitmap.createBitmap(baseWidth, baseHeight, Bitmap.Config.ARGB_8888);
        mCanvas = new Canvas(mBitmap);


        mPath = new Path();
        mBitmapPaint = new Paint(Paint.DITHER_FLAG);

        //mPaint 셋팅.
        mPaint = new Paint();
        mPaint.setAntiAlias(true); // 색이 다른 경계면에서도 부드럽게.
        mPaint.setDither(true); // 이미지보다 장비의 표현력이 떨어질 때 이미지의 색상을 낮추어 출력하는 기법.
        mPaint.setColor(input_color); // 색 input_color로
        mPaint.setStrokeJoin(Paint.Join.ROUND); // 선이 만나는 부분들을 둥글게
        mPaint.setStrokeCap(Paint.Cap.ROUND); // 선의 모서리들을 부드럽게.
        mPaint.setStrokeWidth(stroke); // 굵기

        // mPaint1 셋팅
        mPaint1 = new Paint();
        mPaint1.setAntiAlias(true); // 색이 다른 경계면에서도 부드럽게.
        mPaint1.setDither(true); // 이미지보다 장비의 표현력이 떨어질 때 이미지의 색상을 낮추어 출력하는 기법.
        mPaint1.setColor(input_color); // 색 input_color로
        mPaint1.setStrokeJoin(Paint.Join.ROUND); // 선이 만나는 부분들을 둥글게
        mPaint1.setStrokeCap(Paint.Cap.ROUND); // 선의 모서리들을 부드럽게.
        mPaint1.setStrokeWidth(stroke); // 굵기
    }

    // 초기화 맨 처음 캔버스 화면 생성
    public void init(int x, int y) {
        mBitmap.recycle();
        mBitmap = Bitmap.createBitmap(x, y, Bitmap.Config.ARGB_8888);
        mCanvas = new Canvas(mBitmap);
        invalidate();
    }

    public int getScreenWidth() {
        return baseWidth;
    } // 페인트보드 너비
    public int getScreenHeight() {
        return baseHeight;
    } // 페인트 보드 높이
    public int getStroke() {
        return (int) stroke;
    } // 선 굵기 반환

    // Color 설정하기.
    public void setColor(int color) {
        mMode = 0; // draw 상태
        mPaint.setXfermode(null); // mPaint관련 초기화하고.
        mPaint.setStrokeWidth(stroke); //
        mPaint.setColor(color); // mPaint 색 업데이트.
        mPaint1.setXfermode(null);
        mPaint1.setStrokeWidth(stroke);
        mPaint1.setColor(color);
        input_color = color; // PaintBoard 색 업데이트.
    }

    // stroke 설정하기.
    public void setStroke(float input_stroke) {
        stroke = input_stroke;
        mPaint.setStrokeWidth(stroke);
        mPaint.setColor(input_color);
        mPaint1.setStrokeWidth(stroke);
        mPaint1.setColor(input_color);
    }

    // 지우개 모드 ----------------------------------------------------------------------------------
    public void setClearMode() {
        mMode = 1; // 지우개 모드로
        mPaint.setStrokeWidth(stroke); // 페인트보드 굵기로.
        mPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR)); // 원래 배경은 안건드리고 paint만 건드림.
        mPaint1.setStrokeWidth(stroke);
        mPaint1.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
    }

        // 비트맵 교체
    public void setBackBitmap(Bitmap back) {
        if (mBackBitmap != null) {
            mBackBitmap.recycle(); // 재활용하기.
            mBackBitmap = null;
        }
        mBackBitmap = back;
    }

    public void setreturnMode() {
        mMode = 0;
    } // clear Paint 원래 모드로 돌아가기 (드로우모드)

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        canvas.drawColor(0xffffff);
        if (mBitmap != null)
            canvas.drawBitmap(mBitmap, 0, 0, mBitmapPaint);

        canvas.drawPath(mPath, mPaint); // mPath에 담긴걸 mPaint에 그림. - 이제부터 mPath가 작동하기 시작.
        // drawPath가 무수히 호출됨.
        super.onDraw(canvas);
    }

    //private static final float TOUCH_TOLERANCE = 4;

    // 그림 그리기 동작 부분 -------------------------------------------------------------------------
    static int mX, mY; // 현재 내 위치
    private static int preX, preY; // 이전 위치.

    // 점 맨처음 찍었을 때
    public static void touch_start(int x, int y) {
        MainActivity.mode(x, y, x, y, "0", input_color, stroke, MainActivity.PenStatus);
        mPath.moveTo(x, y);
        mX = x; mY = y;
        preX = x; preY = y;

    }

    // 움직일 때 ------------------------------------------------------------------------------------
    public static void touch_move(int x, int y) {
        if (mMode == 0 || mMode == 1) { // mMode는 0 은 draw  1은 clear
            MainActivity.mode(mX, mY, x, y, "1", input_color, stroke, MainActivity.PenStatus);
            //mPath.quadTo(mX, mY, (x + mX) / 2, (y + mY) / 2); // mx, my 부터 (x+mx)/2, (y+mY)/2 까지 곡선그리기
            mPath.quadTo(mX, mY, x,y); // mx, my 부터 (x+mx)/2, (y+mY)/2 까지 곡선그리기
            mX = x; mY = y;
            /*
            if (mMode == 1) { // clear상태
                mPath.lineTo(mX, mY);
                if (mCanvas != null)
                    mCanvas.drawPath(mPath, mPaint);
                mPath.reset();
                mPath.moveTo(x, y);
                mX = x; mY = y;
                Log.d("그리기중1","move");
            }*/
        }
    }

    public static void touch_up() {
        // 방금찍은 곳 또그릴때.
        if (preX == mX && preY == mY) {
            MainActivity.mode(mX, mY, mX, mY, "3", input_color, stroke, MainActivity.PenStatus);
            if (mCanvas != null) {
                mCanvas.drawPoint(preX, preY, mPaint); // 항상 마지막에는 drawPath나 drawPoint 해주어야함.
            }
        } else {
            MainActivity.mode(mX, mY, mX, mY, "2", input_color, stroke, MainActivity.PenStatus);
            mPath.lineTo(mX, mY);
            if (mCanvas != null)
                mCanvas.drawPath(mPath, mPaint); // 항상 마지막에는 drawPath나 drawPoint 해주어야함.
        }
        mPath.reset();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int x = (int) event.getX();
        int y = (int) event.getY();
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                    switch (MainActivity.PenStatus) {
                            case MainActivity.mode_nomal:
                                mPaint.setStyle(Paint.Style.STROKE);
                                mPaint.setMaskFilter(filter0); // 일반 필터
                                touch_start(x, y);
                                invalidate();
                                break;

                            case MainActivity.mode_neon1:
                                mPaint.setStyle(Paint.Style.STROKE);
                                mPaint.setMaskFilter(filter1); // 네온1 필터
                                touch_start(x, y);
                                invalidate();
                                break;
                            case MainActivity.mode_neon2:
                                mPaint.setStyle(Paint.Style.STROKE);
                                mPaint.setMaskFilter(filter2); // 네온2 필터
                                touch_start(x, y);
                                invalidate();
                                break;
                            case MainActivity.mode_spray1:
                                mPaint.setStyle(Paint.Style.STROKE);
                                mPaint.setMaskFilter(filter3); // 스프레이1 필터
                                touch_start(x, y);
                                invalidate();
                                break;
                            case MainActivity.mode_spray2:
                                mPaint.setStyle(Paint.Style.STROKE);
                                mPaint.setMaskFilter(filter4); // 스프레이2 필터
                                touch_start(x, y);
                                invalidate();
                                break;
                    }
            case MotionEvent.ACTION_MOVE:
                        touch_move(x, y);
                        invalidate();
                break;

            case MotionEvent.ACTION_UP:
                //toX = (int) event.getX();
                //toY = (int) event.getY();
                        touch_up();
                        invalidate();
                break;

            default:
                break;
        }
        return true;
    }
}
