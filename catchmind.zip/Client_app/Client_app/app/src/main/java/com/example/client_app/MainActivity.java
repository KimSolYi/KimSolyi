package com.example.morprubins;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Date;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.provider.MediaStore.Images.Media;
import android.util.AttributeSet;
import android.util.FloatMath;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.morprubins.colorpicker_test.OnColorSelectedListener;

public class MainActivity extends Activity implements OnClickListener {
    // 그리기 관련 변수 ----
    int MX, MY;
    private int lastX, lastY;
    private Dialog mDialog = null;

    String name, rename;

    // 채팅 관련 변수 --
    static TextView textView;
    static ScrollView sc; // 스크롤뷰 (채팅 기록되는 곳)
    Button sendButton; // 채팅 전송버튼
    EditText inputField; // 내 채팅 입력하는 곳.

    // 전체적인 내용 받는 변수 ---
    static String received; // 1차적으로 데이터 받아서 ' ` ' 분리
    static String[] buffer; // 2차적으로 데이터 분리 ','

    // 컬러 관련 변수 --
    static int CurrentColor; // 내가 선택한 컬러색

    // 네트워크 관련 변수 --
    Socket socket;
    static DataInputStream input;
    static DataOutputStream output;
    public static String SERVER_IP = "10.0.2.2";
    public static int SERVER_PORT = 30000;

    // 펜 종류
    public static int PenStatus = 0;
    public static final int mode_nomal = 0;
    public static final int mode_neon1 = 1;
    public static final int mode_neon2 = 2;
    public static final int mode_spray1 = 3;
    public static final int mode_spray2 = 4;

    // 펜
    public static int PenStyle = 0;
    public static final int nomal = 0;
    public static final int fill = 1;
    public static final AttributeSet AttributeSet = null;
    public static final MotionEvent MotionEvent = null;

    // 펜 굵기 관련 변수 -----------------------------------------------------------------------------
    private int currentBold = 10; // 초기 seekBarValueTextView 값. / 현재 굵기값
    private int mNumber = 2; // 메뉴 리스트 초기 선택값. / 그 메뉴 배열의 몇번쨰가 선택되었는지.
    private SeekBar mSeekBarPenWidth;
    private TextView seekBarValueTextView;

    // 펜 삭제 관련 변수 -----------------------------------------------------------------------------
    static String clear = "clear_NO";

    static View view, view1;
    int color = Color.RED;
    float stroke = 10;
    int penstyle = 0; // 펜 스타일
    int repenstyle = 0;

    int X, Y;

    // 화면 관련 -----------------------------------------------------------------------------------
    static Main_PaintBoard pb; //
    static TextView tv_noLogin; // 로그인이 필요합니다 textview

    static Path mPath, mPath1;
    private int mX = 0, mY = 0;
    int preX, preY;

    private static final int DIALOG_CUSTOM_LAYOUT = 0;
    private static final int REQ_CODE_PICK_IMAGE = 0;

    private int baseWidth, baseHeight; // Draw 하는 곳의 크기.

    static final int NONE = 0;
    static final int DRAG = 1;
    static final int ZOOM = 2;
    int mode = NONE;

    Button b_color, b_bold, b_clear, b_save, b_galary, b_board, b_penstyle;
    Button s_nomal, s_neon, s_neon1, s_spray, s_spray1;
    LinearLayout Penstyle_Layout, Penstyle_Sub_Layout, drop_pen;
    private String mName; // 파일 저장한거 이름.

    @Override
    public void onCreate(Bundle savedInstanceState) {
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        // 펜 스타일 레이아웃 ------------------------------------------------------------------------
        Penstyle_Layout = (LinearLayout) findViewById(R.id.layout_menu);
        Penstyle_Sub_Layout = (LinearLayout) findViewById(R.id.layout_style);

        // 펜 스타일 버튼 들 ------------------------------------------------------------------------
        s_nomal = (Button) findViewById(R.id.pen_nomal);
        s_neon = (Button) findViewById(R.id.pen_neon);
        s_neon1 = (Button) findViewById(R.id.pen_neon1);
        s_spray = (Button) findViewById(R.id.pen_spray);
        s_spray1 = (Button) findViewById(R.id.pen_spray1);

        // 전체 버튼 종류 ---------------------------------------------------------------------------
        b_penstyle = (Button) findViewById(R.id.menu_pen_select); // 펜종류
        b_color = (Button) findViewById(R.id.menu_color); // 색
        b_bold = (Button) findViewById(R.id.menu_bold); // 굵기
        b_galary = (Button) findViewById(R.id.menu_galary); // 갤러리
        b_clear = (Button) findViewById(R.id.menu_clear); // 삭제
        b_board = (Button) findViewById(R.id.menu_paintboard);
        b_save = (Button) findViewById(R.id.menu_save); // 이미지 저장.
        
        // 펜 종류 이벤트 리스너 달기 ----------------------------------------------------------------
        s_nomal.setOnClickListener(this);
        s_neon.setOnClickListener(this);
        s_neon1.setOnClickListener(this);
        s_spray.setOnClickListener(this);
        s_spray1.setOnClickListener(this);

        // 초기 메뉴
        b_penstyle.setOnClickListener(this);
        b_color.setOnClickListener(this);
        b_bold.setOnClickListener(this);
        b_galary.setOnClickListener(this);
        b_clear.setOnClickListener(this);
        b_board.setOnClickListener(this);
        b_save.setOnClickListener(this);

        // 전송 관련 --------------------------------------------------------------------------------
        sendButton = (Button) findViewById(R.id.sendButton); // 전송버튼
        sendButton.setOnClickListener(this);
        inputField = (EditText) findViewById(R.id.inputField);

        // 채팅이 출력되는 곳. Scroller와 textview ---------------------------------------------------
        sc = (ScrollView) findViewById(R.id.textScroller);
        textView = (TextView) findViewById(R.id.textView);

        // 메인 그림 보드 view -----------------------------------------------------------------------
        view = (View) findViewById(R.id.front_drawboard);
        pb = (Main_PaintBoard) findViewById(R.id.front_drawboard);
        view.setVisibility(View.INVISIBLE); // 처음에 draw_board를 안보이게
        baseWidth = pb.getScreenWidth();
        baseHeight = pb.getScreenHeight();

        // 로그인이 필요합니다 textview --------------------------------------------------------------
        tv_noLogin = (TextView) findViewById(R.id.text_first);

        mPath = new Path();

        //////// 로그인 부분 처음 시작
        intro();
    }

    public void intro() {
        print("캐치마인드 채팅에 접속하셨습니다! (v1.0)");
        print("로그인 아이디를 입력하시고 전송 버튼을 눌러 주세요.");
        mPath.reset();
    }

    // 컬러 picker 다이얼로그 - 컬러 색 정하기---------------------------------------------------------
    // onClick에서 
    public void colorpicker() {
        colorpicker_test cpd = new colorpicker_test(this, 0xFF00FF00, new OnColorSelectedListener() {
            public void colorSelected(Integer color) {
                colorChanged(color); // 색 변경
                CurrentColor = color; // 현재 섹
            }
        });
        cpd.setTitle("색 고르기");
        cpd.setNoColorButton(R.string.no_color);
        cpd.show();
    }

    // 내가 고른 색으로 바꾸기.
    public void colorChanged(int color) {
        Main_PaintBoard.mPaint.setColor(color);
        Main_PaintBoard.mPaint1.setColor(color);
        Main_PaintBoard.input_color = Main_PaintBoard.mPaint.getColor();
        pb.setColor(Main_PaintBoard.input_color);
    }
    // ------ 컬러 ----------------------------------------------------------------------------------

    // 펜 굵기 -------------------------------------------------------------------------------------
    @Override
    protected Dialog onCreateDialog(int id) {
        //2 ,5, 10, 17, 30, 50, 70 메뉴 배열 array
        final CharSequence[] selectBoldArray = getResources().getStringArray(R.array.bold);
        LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        final View viewInDialog = inflater.inflate(R.layout.pensize, null); // seekBar 넣기.

        // 굵기 커스텀 다이얼로그 만들기
        AlertDialog.Builder penWidthDialog = new AlertDialog.Builder(this);
        penWidthDialog.setTitle("선 굵기 선택");
        penWidthDialog.setSingleChoiceItems(selectBoldArray, mNumber, new DialogInterface.OnClickListener() {
            // selectBoldArray 배열로, mNumber(몇번 째 것이 선택됬는지) 가진 버튼리스트들 생성.
            public void onClick(DialogInterface dialog, int item) {
                String bold_size = selectBoldArray[item].toString(); // 클릭한 것 크기 받아오기.
                pb.setStroke(Integer.parseInt(bold_size)); // 페인트보드의 굵기 바꿔주기.
                mNumber = item; // mNumber의 값이 선택 되어 있다.
                currentBold = Integer.parseInt(bold_size); // 현재 굵기값.
                mSeekBarPenWidth.setProgress(Integer.parseInt(bold_size));
            }
        });

        penWidthDialog.setView(viewInDialog);
        penWidthDialog.setPositiveButton("확인", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss(); // 다이얼로그 종료.
            }
        });

        // seekBar에 대한 이벤트
        mSeekBarPenWidth = (SeekBar) viewInDialog.findViewById(R.id.seekbar);
        mSeekBarPenWidth.setProgress(currentBold); // 초기값 10 적용.

        // textview 값 수정.
        seekBarValueTextView = (TextView) viewInDialog.findViewById(R.id.seekbarvalue);
        seekBarValueTextView.setText("펜굵기 : " + String.valueOf(currentBold));

        mSeekBarPenWidth.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onStopTrackingTouch(SeekBar seekBar) { }
            public void onStartTrackingTouch(SeekBar seekBar) { }
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                seekBarValueTextView.setText("펜굵기 : " + String.valueOf(progress));
                pb.setStroke(progress);
                currentBold = progress;
            }
        });
        penWidthDialog.create();
        penWidthDialog.show();
        
        return null;
    }
    // ------------- 펜 굵기 설정 끝 ----------------------------------------------------------------

    // image 저장 및 갤러리 확인 ---------------------------------------------------------------------
    public void DrawBoardSave() {
        RelativeLayout r = (RelativeLayout) findViewById(R.id.drawimage1);
        RayoutToBitmap(r);
    }

    // 레이아웃을 비트맵으로 저장.
    public void RayoutToBitmap(RelativeLayout rl) {
        rl.invalidate();
        rl.setDrawingCacheEnabled(true);

        Bitmap b = null;
        b = rl.getDrawingCache();
        mName = getCurrentTime()+".jpeg"; // 파일이름 현재시간으로 저장.
        String dir = Environment.getExternalStorageDirectory() + "/DrawTest_image/";

        File folder = new File(dir);
        if (!folder.exists()) {
            folder.mkdirs();
        }
        folder = null;

        File file = new File(dir, mName);
        FileOutputStream outputStream = null;
        try {
            outputStream = new FileOutputStream(file);
            b.compress(CompressFormat.JPEG, 100, outputStream);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        b = null; file = null; // 다 저장후에 사용한 변수 비워주기.
        outputStream = null;
    }

    // 현재시간 리턴
    public String getCurrentTime() {
        long time = System.currentTimeMillis();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd_HH_mm_ss");
        Date dd = new Date(time);
        String strTime = sdf.format(dd);
        return strTime;
    }

    private void MediaScan() {
        String imagepath = Environment.getExternalStorageDirectory() + "/DrawTest_image/" + mName;
        Toast.makeText(MainActivity.this, "파일이 저장되었습니다 !", Toast.LENGTH_SHORT).show();
        Log.d("imagepath", "imagepath = " + imagepath);

        ContentValues values = new ContentValues(2);
        values.put(Media.MIME_TYPE, "image/jpeg");
        values.put(MediaStore.Images.Media.DATA, imagepath);

        ContentResolver resolver = getContentResolver();
        Uri uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
        sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, uri));
    }

	// 갤러리 열기
	private void LoadImage() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, REQ_CODE_PICK_IMAGE);
    }
    // image 저장 및 갤러리 확인 끝
    // -----------------------------------------------------------------
    // 내 채팅창에 출력하기.
    public static void print(Object message) {
        Log.d("RECEIVE_SPLIT", (String) message);
        String msg = (String) message;
        textView.append("* "+msg + "\n");
    }

    // 삭제 눌렀을 때 다이얼로그창 --------------------------------------------------------------------
    private void DeleteDialog() {
        final View innerView = getLayoutInflater().inflate(R.layout.delete_dialog, null);

        // 다이얼로그 생성
        mDialog = new Dialog(this);
        mDialog.setTitle("삭제");
        mDialog.setContentView(innerView); // 내용 xml로
        mDialog.setCancelable(true); // 다이얼로그 밖에 선택시 Dialog 사라지게 하기.
        mDialog.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND); // 다이얼로그 호출시 검정색배경화면 되는거 막기
        mDialog.getWindow().setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL); // 다이얼로그 밖에 VIEW를 터치할 수 있게 하기.
        mDialog.show();
    }

    // 버튼누른후에 자동으로 닫기.
    private void dismissDialog() {
        if (mDialog != null && mDialog.isShowing()) {
            mDialog.dismiss(); // 자동닫기
        }
    }
    // 삭제 다이얼로그 끝 ----------------------------------------------------------------------------

    // 클릭시 이벤트 onClick 총 묶음.
    public void onClick(View view) {
        switch (view.getId()) {
            // 1. 펜 활성화 비활성화 여부 (내 턴 or 상대턴) -----------------------------------------------
            case R.id.menu_paintboard:
                if (pb.getVisibility() == View.VISIBLE) {
                    b_board.setText("펜 비활성");
                    b_board.setTextColor(0xffff0000);
                    pb.setVisibility(View.INVISIBLE);
                } else {
                    b_board.setText("펜 활성");
                    b_board.setTextColor(0xff008040);
                    pb.setVisibility(View.VISIBLE);
                }
                break;

            // 2. 펜 스타일 (일반, 네온1, 네온2, 스프레이1 , 스프레이2) ------------------------------------
            case R.id.menu_pen_select: // 펜 스타일 고르기 레이아웃
                Penstyle_Layout.setVisibility(View.INVISIBLE); // 원래 layout 안보이게 해놓고
                Penstyle_Sub_Layout.setVisibility(View.VISIBLE); // 숨겨진 layout 보이게 함.
                break;

            case R.id.pen_nomal:// 일반
                PenStatus = mode_nomal; // 현재 펜 스타일 상태 (일반)
                Penstyle_Layout.setVisibility(View.VISIBLE);
                Penstyle_Sub_Layout.setVisibility(View.INVISIBLE);
                break;
            case R.id.pen_neon: // 네온1
                PenStatus = mode_neon1; // 현재 펜 스타일 상태 (네온1)
                Penstyle_Layout.setVisibility(View.VISIBLE);
                Penstyle_Sub_Layout.setVisibility(View.INVISIBLE);
                break;
            case R.id.pen_neon1: // 네온2
                PenStatus = mode_neon2; // 현재 펜 스타일 상태 (네온2)
                Penstyle_Layout.setVisibility(View.VISIBLE);
                Penstyle_Sub_Layout.setVisibility(View.INVISIBLE);
                break;
            case R.id.pen_spray: // 스프레이1
                PenStatus = mode_spray1; // 현재 펜 스타일 상태 (스프레이1)
                Penstyle_Layout.setVisibility(View.VISIBLE);
                Penstyle_Sub_Layout.setVisibility(View.INVISIBLE);
                break;
            case R.id.pen_spray1: // 스프레이2
                PenStatus = mode_spray2; // 현재 펜 스타일 상태 (스프레이2)
                Penstyle_Layout.setVisibility(View.VISIBLE);
                Penstyle_Sub_Layout.setVisibility(View.INVISIBLE);
                break;
            // -------------------------------------------------------------------------------------

            // 3. 펜 컬러 ------------------------------------------------------------------------------
            case R.id.menu_color:
                colorpicker();
                break;

            // 4. 펜 굵기 ------------------------------------------------------------------------------
            case R.id.menu_bold:
                showDialog(DIALOG_CUSTOM_LAYOUT);
                break;

            // 5. 삭제 메뉴 ----------------------------------------------------------------------------
            case R.id.menu_clear:
                Toast.makeText(getApplicationContext(), "삭제할 메뉴를 골라주세요", Toast.LENGTH_SHORT).show();
                DeleteDialog(); // 삭제하는 다이얼로그 등장.
                // 올클리어 or 지우개
                break;

            // 지우개 원하는 부분 지우기
            case R.id.btn_clean:
                Toast.makeText(getApplicationContext(), "지우개 선택", Toast.LENGTH_SHORT).show();
                clear = "clear_NO";
                dismissDialog(); // 다이얼로그 끔.
                try {
                    //output.writeInt(12);
                    output.writeUTF("a`" + clear);
                    output.flush();
                } catch (IOException e) {
                    view.setVisibility(View.INVISIBLE);
                    tv_noLogin.setVisibility(View.VISIBLE); // 로그인이 필요합니다
                    print("메시지 전송을 실패하였습니다.");
                }
                break;

            // 초기화 (전체 지우기)
            case R.id.btn_clear:
                Toast.makeText(getApplicationContext(), "전체 지우기 완료", Toast.LENGTH_SHORT).show();
                pb.init(baseWidth, baseHeight); // 완전 캔버스를 바꿈
                clear = "clear_OK";
                dismissDialog(); // 다이얼로그 끔.
                try {
                    //output.writeInt(12);
                    output.writeUTF("a`" + clear);
                    output.flush();
                } catch (IOException e) {
                    view.setVisibility(View.INVISIBLE);
                    tv_noLogin.setVisibility(View.VISIBLE); // 로그인이 필요합니다
                    print("메시지 전송을 실패하였습니다.");
                }
                break;
            // 삭제 끝-------------------------------------------------------------------------------

            // 갤러리 보기 --------------------------------------------------------------------------
            case R.id.menu_galary:
                    LoadImage();
                break;

            // 그림 파일 저장 -----------------------------------------------------------------------
            case R.id.menu_save:
                DrawBoardSave();
                MediaScan(); // 파일 저장
                break;

            // 채팅 전송. ---------------------------------------------------------------------------
            case R.id.sendButton:
                // 메시지 보낼떄 아무것도 안쳤으면 그냥 return
                if (inputField.getText().toString() == "")
                    return;

                if (name == null) {
                    String text = inputField.getText().toString();
                    inputField.setText("");
                    name = text;
                    connect();
                } else {
                    String text = inputField.getText().toString();
                    inputField.setText("");
                    sc.fullScroll(ScrollView.FOCUS_DOWN); // 스크롤이 꽉차면 자동으로 스크롤 뷰가 내려가게.
                    try {
                        output.writeUTF("c`" + text);
                        output.flush();
                    } catch (IOException e) {
                        view.setVisibility(View.INVISIBLE);
                        tv_noLogin.setVisibility(View.VISIBLE); // 로그인이 필요합ㄴ디ㅏ
                        print("메시지 전송을 실패하였습니다.");
                    }
                }
                break;
        }
    }

    // 점과 그 점에 대한 데이터를 옮김.
    public static int mode(int datamx, int datamy, int datax, int datay, String event_status, int color, float stroke, int penstyle) {
        try {
            output.writeUTF("d`" +
                            datamx + "," + // 현재x
                            datamy + "," + // 현재y
                            datax + "," + // 이전x
                            datay + "," + // 이전y
                            event_status + "," + // 내 펜이 move인지, touch인지, up인지
                            color + "," + // 색
                            stroke + "," + // 두께
                            penstyle // 선스타일
                    //PenStatus+","+
                    //filter
            );
            output.flush();
        } catch (IOException e) {
            view.setVisibility(View.INVISIBLE);
            tv_noLogin.setVisibility(View.VISIBLE); // 로그인이 필요합니다.
            print("메시지 전송을 실패하였습니다.");
        }
        return 0;
    }

    // 서버와 연결하기.
    public void connect() {
        try {
            print(SERVER_IP + ":" + SERVER_PORT + "로 접속 중...");
            socket = new Socket(SERVER_IP, SERVER_PORT);
            input = new DataInputStream(socket.getInputStream());
            output = new DataOutputStream(socket.getOutputStream());

            while (socket != null) {
                if (socket.isConnected()) {
                    output.writeUTF("r`1`1`" + name + "`"); // 처음에 register 목적
                    output.flush();
                    view.setVisibility(View.VISIBLE); // 앞 창 불러오기.
                    tv_noLogin.setVisibility(View.INVISIBLE); // 로그인이 필요합니다. 안보이게.
                    break;
                }
            }
            // 메시지 수신 스레드 작동.
            MessageReceiver messageReceiver = new MessageReceiver(); // 메시지 수신하는 스레드 작동.
            messageReceiver.start();
        } catch (Exception e) {
            print("서버에 접속할 수 없습니다.");
            this.finish();
        }
    }

    public String chatMessage;
    Message message;
    int a; // 이벤트상태

    // 메시지 수신용 스레드
    public class MessageReceiver extends Thread {
        public void run() {
            try {
                while ((received = input.readUTF()) != null) {
                    Log.d("RECEIVE", received); // 넘어오는 데이터
                    buffer = received.split("`"); // buffer에
                    // 채팅일떄는 c`유저이름`채팅내용.
                    // 다른사람들어왔을때 n`kkk님이 입장하셨습니다.

                    switch (buffer[0].charAt(0)) {
                        // d(드로잉), n(새로운사람), c(채팅), a(다지우기), x

                        // 새로운 사람이 들어왔을 때. (다른 사람기준) 본인은 c가 호출됨.
                        case 'n': // HI 님이 입장했습니다.
                            chatMessage = "★★★" + buffer[1] + "★★★";
                            message = handler.obtainMessage(1, received);
                            handler.sendMessage(message);
                            break;

                        // 채팅일때
                        case 'c': // c`선민`안녕안녕
                            chatMessage = buffer[1] + ": " + buffer[2]; // buffer1은 유저이름, buffer2는 채팅내용.
                            message = handler.obtainMessage(1, received);
                            handler.sendMessage(message);
                            break;

                        // 일반적으로 그려질떄 (drawing)
                        case 'd': // d`선민`669, 88, 673, 77, 1, -5177406, 10.0, 1
                            String[] bf = buffer[2].split(",");
                            MX = Integer.parseInt(bf[0]); MY = Integer.parseInt(bf[1]); // 현재 X,Y 좌표 상태
                            X = Integer.parseInt(bf[2]); Y = Integer.parseInt(bf[3]); // 다음받아온 X,Y좌표 상태
                            a = Integer.parseInt(bf[4]); // 현재 이벤트 상태 touch, move, touch_up -> 0에서 시작해서 2로 끝남 보통.
                            color = Integer.parseInt(bf[5]);
                            stroke = Float.parseFloat(bf[6]); // 굵기 ( 2.0 ~ 70.0 )
                            penstyle = Integer.parseInt(bf[7]); // 펜 스타일 (0 ~ 4) - 0:일반, 1:네온1, 2:네온2, 3:스프레이1, 4:스프레이2

                            rename = buffer[1]; // 그리고 있는 사람의 이름.
                            chatMessage = buffer[1] + ": " +
                                    "mx좌표 : " + MX + "my좌표 : " + MY +
                                    "x좌표 : " + X + "y좌표 : " + Y +
                                    "상태 : " + a + "색깔 : " + color +
                                    "굵기 : " + stroke + "스탈 : " + penstyle;
                            message = handler1.obtainMessage(1, received);
                            handler1.sendMessage(message);
                            break;

                        // 초기화할경우
                        case 'a':
                            rename = buffer[1]; // 초기화 한 사람.
                            clear = buffer[2]; // clear_ok or clear_no
                            //chatMessage = buffer[1] + ": " + clear;
                            if(clear.equals("clear_NO")){
                                pb.setClearMode(); // 지우개 모드 -> 지우는 색으로 그려주는 거라
                            }

                            message = handler2.obtainMessage(1, received);
                            handler2.sendMessage(message);
                            break;
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    // 채팅메시지 보낼때 (c) / 뉴비들어왔을때 (n)
    Handler handler = new Handler() {
        public void handleMessage(Message message) {
            super.handleMessage(message);
            print(chatMessage);
			/*if(clear == 1){
				Toast.makeText(getApplicationContext(), "", 1).show();
				mPath.reset();
				pb = (PaintBoard)findViewById(R.id.front_drawboard);
				int baseWidth = pb.getScreenWidth();
		        int baseHeight = pb.getScreenHeight();
				pb.init(baseWidth, baseHeight);
				clear = 0;
			}*/
            sc.fullScroll(sc.FOCUS_DOWN);
        }
    };

    // 일반적으로 draw정보들 핸들러
    Handler handler1 = new Handler() {
        public void handleMessage(Message message) {
            super.handleMessage(message);
            if (rename.equals(name)) { } // 그림 그리는 유저가 동일할 때.
            else { // 그림 그리려는 유저가 바뀌었을때
                Main_PaintBoard.mPaint1.setAntiAlias(true);
                Main_PaintBoard.mPaint1.setDither(true);
                Main_PaintBoard.mPaint1.setStrokeJoin(Paint.Join.ROUND);
                Main_PaintBoard.mPaint1.setStrokeCap(Paint.Cap.ROUND);
                Main_PaintBoard.mPaint1.setStyle(Paint.Style.STROKE);
                Main_PaintBoard.mPaint1.setStrokeWidth(stroke);
                Main_PaintBoard.mPaint1.setColor(color);
                if (penstyle != repenstyle) {
                    Log.d("펜스타일","펜스타일");
                    switch (penstyle) {
                        case 0: // 일반 노말상태
                            Main_PaintBoard.mPaint1.setMaskFilter(Main_PaintBoard.filter0); //
                            break;
                        case 1: // 네온1
                            Main_PaintBoard.mPaint1.setMaskFilter(Main_PaintBoard.filter1);
                            break;
                        case 2: // 네온2
                            Main_PaintBoard.mPaint1.setMaskFilter(Main_PaintBoard.filter2);
                            break;
                        case 3: // 스프레이1
                            Main_PaintBoard.mPaint1.setMaskFilter(Main_PaintBoard.filter3);
                            break;
                        case 4: // 스프레이2
                            Main_PaintBoard.mPaint1.setMaskFilter(Main_PaintBoard.filter4);
                            break;
                    }
                    repenstyle = penstyle;
                }

                if (a == 0) { // touch_start 상태.
                    recv_touch_start(X, Y);
                    view.invalidate();
                    Log.d("들름1","들름1");
                    //cycle = 1;
                }

                else if (a == 1) { // touch_move중일떄
                    recv_touch_move(X, Y);
                    view.invalidate();
                    Log.d("들름2","들름2");

                }

                else if (a == 2 || a == 3) { // touch_up일 때
                    recv_touch_up(X, Y);
                    view.invalidate();
                    Log.d("들름3","들름3");
                }
            }
        }
    };

    // 완전 삭제에 대한 handler
    Handler handler2 = new Handler() {
        public void handleMessage(Message message) {
            super.handleMessage(message);
            if (clear.equals("clear_OK")) {
                String clear_noti = "******" + rename + "님이 화면을 초기화 하었습니다." + "******";
                mPath.reset();
                pb = (Main_PaintBoard) findViewById(R.id.front_drawboard);
                int baseWidth = pb.getScreenWidth();
                int baseHeight = pb.getScreenHeight();
                pb.init(baseWidth, baseHeight);
                print(clear_noti);
            }
            else if(clear.equals("clear_NO")){
                String clear_noti = "******" + rename + "님이 지우개 모드를 선택하셨습니다." + "******";
                print(clear_noti);
            }
            sc.fullScroll(sc.FOCUS_DOWN);
            //sc.fullScroll(ScrollView.FOCUS_DOWN);
        }
    };

    public void recv_touch_start(int x, int y) { // 점 찍기
        mPath.moveTo(x, y);
        mX = x; mY = y;
        preX = x; preY = y;
        Log.d("점은","x"+x+","+"y"+y);
    }

    public void recv_touch_move(int x, int y) { // 직선 그리기
        mPath.moveTo(x,y);
//        mPath.quadTo(mX, mY, (x + mX) / 2, (y + mY) / 2);
        mPath.quadTo(mX, mY, x ,y);
        mX = x; mY = y;
        if (Main_PaintBoard.mCanvas != null) {
            Main_PaintBoard.mCanvas.drawPath(mPath, Main_PaintBoard.mPaint1);
            Log.d("어디3","어디3");
        }
    }

    public void recv_touch_up(int x, int y) { // 손 떗을 때 거기까지 그리기
        if (preX == mX && preY == mY) {
            if (Main_PaintBoard.mCanvas != null) {
                Main_PaintBoard.mCanvas.drawPoint(preX, preY, Main_PaintBoard.mPaint1);
                Log.d("어디","어디");
            }
        } else {
            if (Main_PaintBoard.mCanvas != null) {
                Main_PaintBoard.mCanvas.drawPath(mPath, Main_PaintBoard.mPaint1);
                Log.d("어디2","어디2");
            }
        }
        mPath.reset();
    }

    @Override
    public void onDestroy() {
        try {
            super.onDestroy();
            socket.close();
            input.close();
            output.close();
        } catch (IOException e) {
        }
    }
}

