package com.catchmind.server;

import java.io.IOException;
import java.net.ServerSocket;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Server {
	public final static String DESCRIPTON = "welcome to Catchmind server^^";
	public final static int PORT = 30000;
	public final static int VERSION = 0;
	public final static int CHANNEL_COUNT = 4;
	public final static int MAX_USER = 100;

	public static SimpleDateFormat dateFormat;

	public boolean started = false;

	public ServerSocket serverSocket;

	public Admission admission;
	public List<Channel> channels;

	public Server() {
			}

	private boolean initialize() {
		try {
			// ä�� �ִ� 4��.
			channels = new ArrayList<Channel>(CHANNEL_COUNT); // 4��
			for (int i = 0; i < CHANNEL_COUNT; i++) {
				channels.add(new Channel());
			}
			serverSocket = new ServerSocket(Server.PORT);
			admission = new Admission(this.serverSocket, this.channels); // ������ �����.
			return true;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return false;
	}

	public static void log(Object logMessage) {
		System.out.println(timestamp() + " " + logMessage);
	}

	public static String timestamp() {
		dateFormat = new SimpleDateFormat("[hh:mm:ss]");
		return dateFormat.format(new Date());
	}

	public void start() {
		if (started) // ������ ���������� ��.
			return;
		// �⺻ init() �ϰ��� ������ ����.
		if (initialize()) { 
			admission.start();
			started = true;
			log("������ ���������� �ʱ�ȭ�߽��ϴ�.");
		} else {
			log("������ �ʱ�ȭ�� �� �����ϴ�.");
		}
	}
	public static void main(String[] args) {
		System.out.println("*********************************");
		System.out.println("     <Catch mind Server v1.0>    ");
		System.out.println("                                 ");
		System.out.println("*********************************");
		System.out.println("Port: " + Server.PORT + "\n");

		Server server = new Server();
		server.start();
		
		
	}
}
