package com.catchmind.server;

public class User {

	public Connection connection;

	public User() {

	}
}
