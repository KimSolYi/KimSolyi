package com.example.facechange;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;

public class Nose extends Activity implements OnClickListener{
	ImageView im,im1,im2,im3;
	public static int z;
	Intent intent;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.nose);
		init();
		
	}
	
	public void init(){
		im = (ImageView)findViewById(R.id.man_nose1);
		im1 = (ImageView)findViewById(R.id.man_nose2);
		im2 = (ImageView)findViewById(R.id.man_nose3);
		im3 = (ImageView)findViewById(R.id.man_nose4);
		
		im.setOnClickListener(this);
		im1.setOnClickListener(this);
		im2.setOnClickListener(this);
		im3.setOnClickListener(this);
		

	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch(v.getId()){
		case R.id.man_nose1 :
			z = 1;
			intent = new Intent(Nose.this,mouse.class);
			
			startActivity(intent);
			break;
		case R.id.man_nose2 :
			z = 2;
			 intent = new Intent(Nose.this,mouse.class);
			
			startActivity(intent);
			break;
		case R.id.man_nose3 :
			z = 3;
		 intent = new Intent(Nose.this,mouse.class);
		
			startActivity(intent);
			break;
		case R.id.man_nose4 :
			z = 4;
		 intent = new Intent(Nose.this,mouse.class);
		
			startActivity(intent);
			break;
		}
	}
}
