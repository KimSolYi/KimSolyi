package com.example.facechange;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;

public class Hair_Face extends Activity implements OnClickListener{
	ImageView im,im1,im2,im3;
	public static int i;
	Intent intent;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.hair_face);
		init();
	}
	
	public void init(){
		im = (ImageView)findViewById(R.id.man1);
		im1 = (ImageView)findViewById(R.id.man2);
		im2 = (ImageView)findViewById(R.id.man3);
		im3 = (ImageView)findViewById(R.id.man4);
		
		im.setOnClickListener(this);
		im1.setOnClickListener(this);
		im2.setOnClickListener(this);
		im3.setOnClickListener(this);
		
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch(v.getId()){
		case R.id.man1 :
			i = 1;
			 intent = new Intent(Hair_Face.this,Eyes.class);
			startActivity(intent);
			break;
		case R.id.man2 :
			i = 2;
			intent = new Intent(Hair_Face.this,Eyes.class);
			
			startActivity(intent);
			break;
		case R.id.man3 :
			i = 3;
			intent = new Intent(Hair_Face.this,Eyes.class);
			
			startActivity(intent);
			break;
		case R.id.man4 :
			i = 4;
			intent = new Intent(Hair_Face.this,Eyes.class);
			
			startActivity(intent);
			break;
		}
	}
	public static void setI(int i){
		Hair_Face. i = i ;
	}
	public static int getI(){
		return i;
	}
}
