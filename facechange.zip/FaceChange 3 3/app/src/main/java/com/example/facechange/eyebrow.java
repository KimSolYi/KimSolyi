package com.example.facechange;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;

public class eyebrow extends Activity implements OnClickListener{
	ImageView im,im1,im2,im3;
	int i;
	Intent intent;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.eyebrow);
		init();
	}
	
	public void init(){
		im = (ImageView)findViewById(R.id.man_brow1);
		im1 = (ImageView)findViewById(R.id.man_brow2);
		im2 = (ImageView)findViewById(R.id.man_brow3);
		im3 = (ImageView)findViewById(R.id.man_brow4);
		
		im.setOnClickListener(this);
		im1.setOnClickListener(this);
		im2.setOnClickListener(this);
		im3.setOnClickListener(this);
		

	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch(v.getId()){
		case R.id.man_brow1 :
			i = 1;
		intent = new Intent(eyebrow.this,EndActivity.class);
			intent.putExtra("a",i);
			startActivity(intent);
			break;
		case R.id.man_brow2 :
			i = 2;
			 intent = new Intent(eyebrow.this,EndActivity.class);
			 intent.putExtra("a",i);
			startActivity(intent);
			break;
		case R.id.man_brow3 :
			i = 3;
			intent = new Intent(eyebrow.this,EndActivity.class);
			intent.putExtra("a",i);
			startActivity(intent);
			break;
		case R.id.man_brow4 :
			i = 4;
			 intent= new Intent(eyebrow.this,EndActivity.class);
			 intent.putExtra("a",i);
			startActivity(intent);
			break;
		}
	}
}
