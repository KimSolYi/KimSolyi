package com.example.facechange;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Random;


import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

public class EndActivity extends AppCompatActivity implements OnClickListener{
	private Button btn;
	ImageView img,img1,img2,img3,img4;
	Intent intent;
	
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_end);
		init();
		
	}
	public void init(){
		btn = (Button)findViewById(R.id.btn);
		btn.setOnClickListener(this);
		
		img = (ImageView)findViewById(R.id.imageView1);
		img1 = (ImageView)findViewById(R.id.imageView2);
		img2 = (ImageView)findViewById(R.id.imageView5);
		img3 = (ImageView)findViewById(R.id.imageView4);
		img4 = (ImageView)findViewById(R.id.imageView3);
		
	intent = getIntent();
	int i = intent.getIntExtra("a",0);
	
	if(Hair_Face.i == 2){
		img.setBackground((Drawable)getResources().getDrawable(R.drawable.man2));
	}
	else if(Hair_Face.i == 3){
		img.setBackground((Drawable)getResources().getDrawable(R.drawable.man3));
	}
	else if(Hair_Face.i == 4){
		img.setBackgroundResource(R.drawable.man4);
	}
	else {
		img.setBackgroundResource(R.drawable.man1);
	}
	
	
	 if(Eyes.j == 2){
		img1.setBackground((Drawable)getResources().getDrawable(R.drawable.man2_eye));
	}
	else if(Eyes.j == 3){
		img1.setBackground((Drawable)getResources().getDrawable(R.drawable.man3_eye));
	}
	else if(Eyes.j == 4){
		img1.setBackground((Drawable)getResources().getDrawable(R.drawable.man4_eye));
	}
	else{
		img1.setBackground((Drawable)getResources().getDrawable(R.drawable.man1_eye));
	}
	
	if(Nose.z == 2){
		img3.setBackground((Drawable)getResources().getDrawable(R.drawable.man_nose2));
	}
	else if(Nose.z == 3){
		img3.setBackground((Drawable)getResources().getDrawable(R.drawable.man_nose3));
	}
	else if(Nose.z == 4){
		img3.setBackground((Drawable)getResources().getDrawable(R.drawable.man_nose4));
	}
	else{
		img3.setBackground((Drawable)getResources().getDrawable(R.drawable.man_nose1));
		
	}
	if(mouse.y == 2){
		img4.setBackground((Drawable)getResources().getDrawable(R.drawable.man_mouse2));
	}
	else if(mouse.y== 3){
		img4.setBackground((Drawable)getResources().getDrawable(R.drawable.man_mouse3));
	}
	else if(mouse.y== 4){
		img4.setBackground((Drawable)getResources().getDrawable(R.drawable.man_mouse4));
	}
	else{
		img4.setBackground((Drawable)getResources().getDrawable(R.drawable.man_mouse1));
		
	}
	
	if(i == 1){
		img2.setBackground((Drawable)getResources().getDrawable(R.drawable.man_brow1));
	}
	else if(i== 2){
		img2.setBackground((Drawable)getResources().getDrawable(R.drawable.man_brow2));
	}
	else if(i == 3){
		img2.setBackground((Drawable)getResources().getDrawable(R.drawable.man_brow3));
	}
	else{
		img2.setBackground((Drawable)getResources().getDrawable(R.drawable.man_brow4));
	}
	//////////////////////////////////////////////////////////////////////////////////
	
	Random r = new Random();
    int randomValue = r.nextInt(100)+1;
    Toast.makeText(EndActivity.this,"당신과 당신의 이상형은",Toast.LENGTH_SHORT).show();

if(randomValue <= 30){
	Toast.makeText(EndActivity.this,"너무 슬프당ㅜㅜㅜ",Toast.LENGTH_SHORT).show();
	}
else if(randomValue <= 60){
	Toast.makeText(EndActivity.this,"ㅋㅋㅋㅋㅋㅋ",Toast.LENGTH_SHORT).show();
}
else if(randomValue <= 80){
	Toast.makeText(EndActivity.this,"오~~~~~~~~~~~",Toast.LENGTH_SHORT).show();
}
else if(randomValue <= 99){
	Toast.makeText(EndActivity.this,"우와~^^믿을수없지만",Toast.LENGTH_SHORT).show();
	}
Toast.makeText(EndActivity.this,randomValue+"%어울리네요..\n", Toast.LENGTH_SHORT).show();
	
	}
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch(v.getId()){
		case R.id.btn :
			intent = new Intent(EndActivity.this,MainActivity.class);
			startActivity(intent);
			break;
			
		}
	}
	public void mOnCaptureClick(View v){
		//전체화면
		View rootView = getWindow().getDecorView();

		File screenShot = ScreenShot(rootView);
		if(screenShot!=null){
			//갤러리에 추가
			sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(screenShot)));
		}
	}

	//화면 캡쳐하기
	public File ScreenShot(View view){
		view.setDrawingCacheEnabled(true);  //화면에 뿌릴때 캐시를 사용하게 한다

		Bitmap screenBitmap = view.getDrawingCache();   //캐시를 비트맵으로 변환

		String filename = "screenshot.png";
		File file = new File(Environment.getExternalStorageDirectory()+"/Pictures", filename);  //Pictures폴더 screenshot.png 파일
		FileOutputStream os = null;
		try{
			os = new FileOutputStream(file);
			screenBitmap.compress(Bitmap.CompressFormat.PNG, 90, os);   //비트맵을 PNG파일로 변환
			os.close();
		}catch (IOException e){
			e.printStackTrace();
			return null;
		}

		view.setDrawingCacheEnabled(false);
		return file;
	}

}