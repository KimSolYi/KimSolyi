package com.example.facechange;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;

public class mouse1 extends Activity implements OnClickListener{
	ImageView im,im1,im2,im3;
	public static int y;
	Intent intent;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.mouse1);
		init();
	}
	
	public void init(){
		im = (ImageView)findViewById(R.id.woman_mouse1);
		im1 = (ImageView)findViewById(R.id.woman_mouse2);
		im2 = (ImageView)findViewById(R.id.woman_mouse3);
		im3 = (ImageView)findViewById(R.id.woman_mouse4);
		
		im.setOnClickListener(this);
		im1.setOnClickListener(this);
		im2.setOnClickListener(this);
		im3.setOnClickListener(this);
		
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch(v.getId()){
		
		case R.id.woman_mouse1 :
			y = 1;
			intent = new Intent(mouse1.this,eyebrow1.class);
			startActivity(intent);
			break;
			
		case R.id.woman_mouse2 :
			y = 2;
			intent = new Intent(mouse1.this,eyebrow1.class);
			startActivity(intent);
			break;
			
		case R.id.woman_mouse3 :
			y = 3;
			intent = new Intent(mouse1.this,eyebrow1.class);
			startActivity(intent);
			break;
			
		case R.id.woman_mouse4 :
			y = 4;
			intent = new Intent(mouse1.this,eyebrow1.class);
			startActivity(intent);
			break;
		}
	}
}
