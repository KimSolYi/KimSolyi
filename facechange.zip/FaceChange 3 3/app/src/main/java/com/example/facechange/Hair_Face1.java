package com.example.facechange;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;

public class Hair_Face1 extends Activity implements OnClickListener{
	ImageView im,im1,im2,im3;
	public static int i;
	Intent intent;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.hair_face1);
		init();
	}
	
	public void init(){
		im = (ImageView)findViewById(R.id.woman1);
		im1 = (ImageView)findViewById(R.id.woman2);
		im2 = (ImageView)findViewById(R.id.woman3);
		im3 = (ImageView)findViewById(R.id.woman4);
		
		im.setOnClickListener(this);
		im1.setOnClickListener(this);
		im2.setOnClickListener(this);
		im3.setOnClickListener(this);
		
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch(v.getId()){
		
		case R.id.woman1 :
			i = 1;
			intent = new Intent(Hair_Face1.this,Eyes1.class);
			startActivity(intent);
			break;
			
		case R.id.woman2 :
			i = 2;
			intent = new Intent(Hair_Face1.this,Eyes1.class);
			startActivity(intent);
			break;
			
		case R.id.woman3 :
			i = 3;
			intent = new Intent(Hair_Face1.this,Eyes1.class);
			startActivity(intent);
			break;
			
		case R.id.woman4 :
			i = 4;
			intent = new Intent(Hair_Face1.this,Eyes1.class);
			startActivity(intent);
			break;
		}
	}
	

}
