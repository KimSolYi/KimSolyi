package com.example.facechange;


import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class MainActivity extends AppCompatActivity implements OnClickListener{
	private Button btn,btn1,sound;
	MediaPlayer background;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		background = MediaPlayer.create(this, R.raw.music2);
	    background.setLooping(true);
	    background.start();
		init();
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
		
	}
	public void init(){
		btn = (Button)findViewById(R.id.man);
		btn1 = (Button)findViewById(R.id.woman);
		sound=(Button)findViewById(R.id.sound);
		
		btn.setOnClickListener(this);
		btn1.setOnClickListener(this);
		sound.setOnClickListener(this);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch(v.getId()){
		case R.id.man :
		Intent intent = new Intent(MainActivity.this,Hair_Face.class);
		startActivity(intent);
		
			break;
			
		case R.id.woman :
			Intent intent1 = new Intent(MainActivity.this,Hair_Face1.class);
			startActivity(intent1);
		
			break;
			
		case R.id.sound:
			background.stop();
			
	          
			Toast.makeText(MainActivity.this, "�뷡 ����",
	                  Toast.LENGTH_SHORT).show();// Toast
			break;
		}
	}


}
