public class UserInformation  //ArrayList�� ����ϱ� ���ؼ� ���ʸ����� ���� ���� Ŭ�����̴�.
{
	private String ID;
	
	private String name;
	
	private String password;
	
	private String phone;
	
	private int price;
	
	private int mileage;

	public String getID() {
		return ID;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public void setID(String iD) {
		ID = iD;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public int getMileage() {
		return mileage;
	}

	public void setMileage(int mileage) {
		this.mileage = mileage;
	}
	
}