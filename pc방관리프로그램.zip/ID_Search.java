import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class ID_Search extends JFrame implements ActionListener {

   JTextField textfieldName;
   JTextField textfieldPhone1;
   JTextField textfieldPhone2;
   JTextField textfieldPhone3;
   JLabel label2;

   ArrayList<UserInformation> list1 = new ArrayList<UserInformation>();
   UserInformation uif = null;

   public ID_Search() {
      Container cp = getContentPane();
      cp.setLayout(new GridLayout(7, 1));

      JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
      label2 = new JLabel("name");
      panel.add(label2);
      textfieldName = new JTextField();
      textfieldName.setColumns(10);
      panel.add(textfieldName);
      cp.add(panel);

      panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
      JLabel label1 = new JLabel("phone");
      panel.add(label1);
      textfieldPhone1 = new JTextField();
      textfieldPhone1.setColumns(3);
      panel.add(textfieldPhone1);
      textfieldPhone2 = new JTextField();
      textfieldPhone2.setColumns(4);
      panel.add(textfieldPhone2);
      textfieldPhone3 = new JTextField();
      textfieldPhone3.setColumns(4);
      panel.add(textfieldPhone3);
      cp.add(panel);
      panel = new JPanel(new FlowLayout(FlowLayout.CENTER));
      JButton button = new JButton("ã��");
      button.addActionListener(this);
      panel.add(button);
      cp.add(panel);
   }

   public void actionPerformed(ActionEvent e) {

      String command = e.getActionCommand();

      if (command.equals("ã��")) {
         Connect cc = new Connect();
         String user_name = textfieldName.getText();
         String phone1 = textfieldPhone1.getText();
         String phone2 = textfieldPhone2.getText();
         String phone3 = textfieldPhone3.getText();
         list1 = cc.userID_Return(user_name, phone1, phone2, phone3);         
         for(int i=0;i<list1.size();i++) //�α��� �Ǿ��ִ� ����� ��ŭ �ݺ��� ����ȴ�.
           {            
              uif = list1.get(i);//list�� ����� UserInfomation�� get�� �̿��� uif�� �������Ѵ�.
              JOptionPane.showMessageDialog(null, uif.getID() + "/" + uif.getPassword());

           }         
      }
   }

   public static void main() {
      // TODO Auto-generated method stub

      ID_Search frame = new ID_Search();

      frame.setTitle("ã�� ����");
      frame.setSize(600, 300);
      frame.show();

   }

}