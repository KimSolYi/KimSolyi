package spring.myapp.shoppingmall.service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.List;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;

import spring.myapp.shoppingmall.controller.MallController;
import spring.myapp.shoppingmall.dto.Order;
import spring.myapp.shoppingmall.dto.Ordergoods;
import spring.myapp.shoppingmall.dto.Vbank;

public interface OrderService {
	public void deletemerchantid(String merchant_id);
	public String getimp_uid(String merchant_uid);
	public Order getMerchantId(String merchant_id);
	public int getpriceBymerchantid(String merchant_uid);
	public List<Ordergoods> getordergoods(String merchant_id);
	public List<Order> getorderinfo(String id,int curPageNum);
	public Vbank getvbankinfo(String merchant_id);
	public void insertprice(String price,String merchant_uid);
	public void insertgoods(String merchant_id,String[] list,Integer[] glist);
	public void InsertVbank(String merchant_id,String vbanknum,String vbankname,String vbankdate,String vbankholder,String vbankperson,
			String vbankcode);
	public void InsertVbankAndUpdateStatus(String merchant_uid, String vbanknum, String vbankname, String vbankdate,
			String vbankholder, String buyer_name, String vbank_code, String status, String imp_uid, String paymethod,
			String merchant_id, String[] list, Integer[] integerilist, String price,String couponid);
	public void InsertMerchant(String id,String merchant_id,String phoneNumber,String address,String buyer_name,String memo,int price);
	public boolean mobilecheckbymerchantuid(String merchant_uid);
	public void updatestatus(String updatestatus,String merchant_uid,String imp_uid,String paymethod,String price,
			String vbankholder,String vbanknum,String vbankcode);
	public void updatestatusandorder(String status, String merchant_uid, String imp_uid, String paymethod,
			String merchant_id,String[] list, Integer[] integerilist,String price,String vbankholder,
			String vbanknum,String vbankcode,String couponid);
	public int orderpaycheck(String Userid,String price,String coupon);
}
