package spring.myapp.shoppingmall.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import spring.myapp.shoppingmall.dao.MallDao;
import spring.myapp.shoppingmall.dto.Reply;
import spring.myapp.shoppingmall.dto.ReviewReply;

@Service
public class ReplyServiceImpl implements ReplyService{
	@Autowired
	private MallDao Malldao;
	
	@Override
	public List<Reply> commentlist(String gId){
		return Malldao.commentlist(gId);
	}
	
	@Override
	public void contentreplydelete(String gId, String rId){
		Malldao.contentreplydelete(gId,rId);
	}
	
	@Override
	public void contentreplymodify(String gId, String rId, String content){
		Malldao.contentreplymodify(gId,rId,content);
	}
	
	@Override
	public boolean addComment(String gId,String user_id,String reply){
		return Malldao.addComment(gId,user_id,reply);
	}
	
	@Override
	public boolean addreview(Reply reply) {
		return Malldao.addreview(reply);
	}
	
	@Override
	public List<Reply> getAllReply(String bookname){
		return Malldao.getAllReply(bookname);
	}
	
	@Override
	public void addreviewreply(ReviewReply userreview,int rid) {
		Malldao.addreviewreply(userreview,rid);
	}
	@Override
	public void reviewmodify(String content, int reviewid) {
		Malldao.reviewmodify(content,reviewid);
	}

	@Override
	public void reviewdelete(int reviewid) {
		Malldao.reviedelete(reviewid);
	}
	
	@Override
	public void reviewreplydelete(int reviewreplyid) {
		Malldao.reviewreplydelete(reviewreplyid);
	}

	@Override
	public void reviewrecommend(int reviewid,String userid) {
		Malldao.reviewrecommend(reviewid,userid);
	}

	@Override
	public void reviewreplyrecommend(int reviewreplyid,String userid) {
		Malldao.reviewreplyrecommend(reviewreplyid,userid);
	}

	@Override
	public boolean reviewrecommendcheck(int reviewid,String userid) {
		return Malldao.reviewrecommendcheck(reviewid,userid);
	}
	
	@Override
	public boolean reviewreplyrecommendcheck(int reviewreplyid, String userid) {
		return Malldao.reviewreplyrecommendcheck(reviewreplyid,userid);
	}
}
