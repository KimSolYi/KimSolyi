package spring.myapp.shoppingmall.admin;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import spring.myapp.shoppingmall.controller.MallController;
import spring.myapp.shoppingmall.dto.Goods;
import spring.myapp.shoppingmall.dto.Monthbook;
import spring.myapp.shoppingmall.dto.Refund;
import spring.myapp.shoppingmall.paging.Paging;
import spring.myapp.shoppingmall.service.AdminServiceImpl;

@Controller
@RequestMapping(value = "/admin")
public class AdminController 
{
	private static final Logger logger = LoggerFactory.getLogger(AdminController.class);
	
	@Autowired
	private AdminServiceImpl adminserviceimpl;
	
	@Autowired
	private Paging paging;
	
	@RequestMapping(value = "/registerGoods",method = RequestMethod.POST)
	public String registerGoods(@Valid Goods goods,BindingResult result,Model model)  //�����ڰ� å�� ���
	{
		if(result.hasErrors()) {
			List<ObjectError> errors = result.getAllErrors();
			for(ObjectError error : errors) {
				System.out.println("error : " + error);
			}
			model.addAttribute("bigclass",goods.getBigclass());
			return "/admin/adminregister";
		}
		adminserviceimpl.register(goods);
		return "redirect:/admin/registerForm";
	}
	
	@RequestMapping("/monthbookselect")
	public String monthbookselect(HttpServletRequest request,Model model) {
		pagingModelAdmin(model,request);
		return "/admin/monthbookselect";
	}
	
	@RequestMapping("/downmonthbooklist")
	@ResponseBody
	public void downmonthbooklist() {
		adminserviceimpl.downmonthbooklist();
	}
	
	@RequestMapping(value = "/findbook",method = RequestMethod.POST)
	@ResponseBody
	public JSONObject findbook(@RequestParam String name) {
		System.out.println("name : " + name);
		Goods goods = adminserviceimpl.findbook(name);
		JSONObject json = new JSONObject();
		json.put("id",goods.getId());
		json.put("name",goods.getName());
		json.put("price",goods.getPrice());
		json.put("qty",goods.getRemain());
		json.put("purchase",goods.getPurchase());
		json.put("goodsprofile",goods.getGoodsprofile());
		return json;
	}
	
	@RequestMapping(value = "/settodaybookselect",method = RequestMethod.POST)
	@ResponseBody
	public void settodaybookselect(@RequestParam String id) {
		int bookid = Integer.valueOf(id);
		adminserviceimpl.settodaybookselect(bookid);
	}
	
	private Model pagingModelAdmin(Model model,HttpServletRequest request){  //�̴��� �α⼭�� ��� ������ ���������� �����ڰ� ���ŷ��� ������ å��
		 																	  //�� �� �ֵ��� ���ִ� ����¡ ó��
			String page = request.getParameter("page");
			int curPageNum = 0;
			if(page != null)
				curPageNum = Integer.valueOf(page);
			else
				curPageNum = 1; //ó�� �������� ���� ���(����¡ ó���� �������� ������ �ʾ��� ���)
			System.out.println("page : " + page);
			paging.adminpagemakeBlock(curPageNum); //������ ù��° ������ �ѹ� ���ϱ�,������ ������ ������ �ѹ� ���ϱ�
			paging.lastPageNumAdmin();
			Integer blockStartNum = paging.getBlockStartNum();	//������ ���� ������ �ѹ�
			Integer blockLastNum = paging.getBlockLastNum();    //������ ������ ������ �ѹ�
			Integer lastPageNum = paging.getLastPageNum();		//������ ������
			List<Goods> monthbooklist = adminserviceimpl.getmonthbooklist(curPageNum);
			System.out.println("monthbooklist : " + monthbooklist);
			model.addAttribute("monthbooklist",monthbooklist);
			model.addAttribute("list",monthbooklist).addAttribute("curPageNum",curPageNum).addAttribute("blockStartNum",blockStartNum).addAttribute("blockLastNum",blockLastNum).addAttribute("lastPageNum",lastPageNum);
			return model;
	}
	
	@RequestMapping("/setmonthbooklist")
	@ResponseBody
	public void setmonthbooklist(@RequestBody HashMap<String,Object> map) {
		List<String> selectedbooklist = (ArrayList<String>) map.get("selectedbooklist");
		for(int i=0;i<selectedbooklist.size();i++)
			System.out.println(Integer.parseInt(selectedbooklist.get(i)));
		adminserviceimpl.setmonthbooklist(selectedbooklist);
	}
	
	@RequestMapping("/todaybookselect")
	public String todaybookselect() {
		return "/admin/todaybookselect";
	}
	
	@RequestMapping("/registerForm")  //�����ڰ� å�� ����ϴ� ������ ��з��� Ŭ���� �ٸ� ��з��� �̵�
	public String registerForm(@RequestParam(value = "bigclass",required = false) String bigclass,Model model) {
		Goods goods = new Goods();
		model.addAttribute("goods",goods);
		
		if(bigclass == null || bigclass.equals("novel"))
		{
			model.addAttribute("bigclass","novel");
		}
		else if(bigclass.equals("economy"))
		{
			model.addAttribute("bigclass","economy");
		}
		else if(bigclass.equals("humanity"))
		{
			model.addAttribute("bigclass","humanity");
		}
		else if(bigclass.equals("religion"))
		{
			model.addAttribute("bigclass","religion");
		}
		else if(bigclass.equals("science"))
		{
			model.addAttribute("bigclass","science");
		}
		else if(bigclass.equals("politics"))
		{
			model.addAttribute("bigclass","politics");
		}
		else if(bigclass.equals("children"))
		{
			model.addAttribute("bigclass","children");
		}
		else if(bigclass.equals("computer"))
		{
			model.addAttribute("bigclass","computer");
		}
		else if(bigclass.equals("cook"))
		{
			model.addAttribute("bigclass","cook");
		}
		else if(bigclass.equals("textbook"))
		{
			model.addAttribute("bigclass","textbook");
		}
		else if(bigclass.equals("foreign"))
		{
			model.addAttribute("bigclass","foreign");
		}
		else if(bigclass.equals("cartoon"))
		{
			model.addAttribute("bigclass","cartoon");
		}
		else if(bigclass.equals("magazine"))
		{
			model.addAttribute("bigclass","magazine");
		}
		
		return "/admin/adminregister";
	}
	
	@RequestMapping("/adminrefund")  //�����ڰ� ������ ȯ�� ��û�� ���ִ� �������� �̵�
	public String adminrefund() {
		return "/admin/adminrefund";
	}
	
	@RequestMapping(value = "/findrefund",method = RequestMethod.POST)  //������ ȯ�� ��û�� DB���� ��ȸ
	@ResponseBody
	public JSONObject findrefund(@RequestBody HashMap<String,Object> map)
	{
		logger.info((String)map.get("orderid"));
		Refund refund = adminserviceimpl.getrefund((String)map.get("orderid"));  //������ ȯ�� �����͸� ������
		if(refund != null) {
			Integer amount = refund.getAmount();
			String refundholder = refund.getRefundholder();
			String refundbank = refund.getRefundbank();
			String refundaccount = refund.getRefundaccount();
			JSONObject json = new JSONObject();
			json.put("amount", amount);
			json.put("holder",refundholder);
			json.put("bank",refundbank);
			json.put("account",refundaccount);
			return json;
		} else {
			return new JSONObject();
		}
	}
}
