package spring.myapp.shoppingmall.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.inject.Inject;
import javax.sql.DataSource;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import spring.myapp.shoppingmall.dto.Ordergoods;
import spring.myapp.shoppingmall.dto.User;

@Repository
@Transactional
public class UserDao implements UserDaoInterface{
	private JdbcTemplate template;
	
	@Autowired
	private SessionFactory sessionFactory;
	 
	@Inject
	private BCryptPasswordEncoder passwordEncoder;
	
	@Autowired
	public UserDao(DataSource dataSource) {
		this.template = new JdbcTemplate(dataSource);
	}
	
	private Session getSession() {
	    return sessionFactory.getCurrentSession();
	}
	
	public User getUser(String Id) {	//ȸ�� ���� ��������
		/*String sql = "select * from user where Id = ?";
		User user;
		
		user = template.queryForObject(sql,new Object[] {Id},new RowMapper<User>() {
			public User mapRow(ResultSet rs,int RowNum) throws SQLException{
				User user = new User();
				user.setId(rs.getString("Id"));
				user.setAddress(rs.getString("address"));
				user.setPhoneNumber(rs.getString("phonenumber"));
				user.setEmail(rs.getString("email"));
				user.setName(rs.getString("name"));
				
				return user;
			}
		});
		return user;*/
		Session session = sessionFactory.getCurrentSession();
		User user = session.get(User.class,Id);
		return user;
	}
	/*
	@Override
	public void join(String Id,String Password,String Name,String Address,String Sex,int Age,String PhoneNumber,String email) {
		//String sql = "insert into user (Id,Password,Name,Address,Sex,Age,PhoneNumber,email,Authorities,Enabled) values(?,?,?,?,?,?,?,?,'ROLE_USER',1)";
		System.out.println("start join...");
		Session session = sessionFactory.getCurrentSession();
		System.out.println("join check...");
		User user = new User();
		user.setId(Id);
		user.setPassword(Password);
		user.setName(Name);
		user.setAddress(Address);
		user.setSex(Sex);
		user.setAge(Age);
		user.setPhoneNumber(PhoneNumber);
		user.setEmail(email);
		user.setAuthorities("ROLE_USER");
		user.setEnabled(1);
		session.save(user);
		//template.update(sql,new Object[] {Id,Password,Name,Address,Sex,Age,PhoneNumber,email});
	}public void join(String Id,String Password,String Name,String Address,String Sex,int Age,String PhoneNumber,String email);
	*/
	
	@Override
	public void join(User user) {
		//String sql = "insert into user (Id,Password,Name,Address,Sex,Age,PhoneNumber,email,Authorities,Enabled) values(?,?,?,?,?,?,?,?,'ROLE_USER',1)";
		System.out.println("start join...");
		Session session = sessionFactory.getCurrentSession();
		System.out.println("join check...");
		user.setAuthorities("ROLE_USER");
		user.setEnabled(0);
		user.setGrade("Bronze");
		session.save(user);
		//template.update(sql,new Object[] {Id,Password,Name,Address,Sex,Age,PhoneNumber,email});
	}
	
	
	public boolean authId(String e_mail,String phoneNumber,String name)
	{
		/*
		String sql = "select * from user where name = ? and phonenumber = ? and email = ?";
		User user;
		try {
		user = template.queryForObject(sql,new Object[] {name,phoneNumber,e_mail},new RowMapper<User>() {
			public User mapRow(ResultSet rs,int rowNum) throws SQLException
			{
				User user = new User();
				user.setEmail(rs.getString("email"));
				
				return user;
			}
		});
			return true;
		}
		catch(EmptyResultDataAccessException e)
		{
			return false;
		}*/
		Session session = getSession();
		Query<User> query = session.createQuery("from User where name = :name and phoneNumber = :phoneNumber and email = :email");
		query.setParameter("name",name);
		query.setParameter("phoneNumber",phoneNumber);
		query.setParameter("email",e_mail);
		List<User> userlist = query.getResultList();
		if(userlist.size() > 0) {
			return true;
		} else {
			return false;
		}
		
		
		/*
		if(user.getUseremail().equals(e_mail))
			return true;
		else
			return false;
		*/
	}
	
	public boolean authPw(String cId,String e_mail,String phoneNumber,String name)
	{
		/*
		String sql = "select * from user where id = ? and name = ? and email = ? and phonenumber = ?";
		User user;
		
		try {
		user = template.queryForObject(sql,new Object[] {cId,name,e_mail,phoneNumber},new RowMapper<User>() {
			public User mapRow(ResultSet rs,int rowNum) throws SQLException
			{
				User user = new User();
				user.setEmail(rs.getString("email"));
				
				return user;
			}
		});
			return true;
		}
		catch(EmptyResultDataAccessException e)
		{
			return false;
		}
		*/
		Session session = getSession();
		Query<User> query = session.createQuery("from User where id = :id and name = :name and email = :email and phoneNumber = :phoneNumber");
		query.setParameter("id",cId);
		query.setParameter("name",name);
		query.setParameter("phoneNumber",phoneNumber);
		query.setParameter("email",e_mail);
		List<User> userlist = query.getResultList();
		if(userlist.size() > 0) {
			return true;
		} else {
			return false;
		}
		
		/*
		if(user.getUseremail().equals(e_mail))
			return true;
		else
			return false;
		*/
	}
	
	public User findId(String name,String phoneNumber)
	{
		/*
		String sql = "select * from user where name = ? and phonenumber = ?";
		User user;
		
		try {
		  user = template.queryForObject(sql,new Object[] {name,phoneNumber},new RowMapper<User>() {
			  public User mapRow(ResultSet rs,int rowNum) throws SQLException
			  {
				  User user = new User();
				  user.setId(rs.getString("Id"));
				  
				  return user;
			  }
		  });
		}catch(Exception e)
		{
			return null;
		}
		
		System.out.println("UserId: "+user.getId());
		return user;
		*/
		Session session = getSession();
		Query<User> query = session.createQuery("from User where name = :name and phoneNumber = :phoneNumber");
		query.setParameter("name",name);
		query.setParameter("phoneNumber",phoneNumber);
		List<User> userlist = query.getResultList();
		if(userlist.size() > 0) {
			return userlist.get(0);
		} else {
			return null;
		}
	}
	
	public User findPw(String cId)
	{
		/*
		String sql = "select * from user where Id = ?";
		User user;
		
		try {
		  user = template.queryForObject(sql,new Object[] {cId},new RowMapper<User>() {
			  public User mapRow(ResultSet rs,int rowNum) throws SQLException
			  {
				  User user = new User();
				  //String cPw = rs.getString("cPw").substring(6);
				  //String cId = rs.getString("cId");
				  //user.setUserpassword(cPw);
				  user.setId(rs.getString("Id"));
				  
				  return user;
			  }
		  });
		}catch(Exception e)
		{
			return null;
		}
		*/
		Session session = getSession();
		Query<User> query = session.createQuery("from User where id = :id",User.class);
		query.setParameter("id",cId);
		List<User> userlist = query.getResultList();
		if(userlist.size() == 1) {
			return userlist.get(0);
		}else {
			return null;
		}
		//return user;
	}
	public void repassword(String userId,String repassword)
	{
		/*
		String sql = "update user set Password = ? where Id = ?";
		String encPassword = passwordEncoder.encode(repassword);
		template.update(sql,new Object[] {encPassword,userId});
		*/
		Session session = getSession();
		String encPassword = passwordEncoder.encode(repassword);
		Query query = session.createQuery("update User set password = :password where id = :id");
		query.setParameter("password",encPassword);
		query.setParameter("id",userId);
		query.executeUpdate();
	}
	
	public int check(String id)
	{
		/*
		String sql = "select * from user where Id = ?";
		List<User> list = null;
		
		list = template.query(sql,new Object[] {id},new RowMapper<User>() {
			public User mapRow(ResultSet rs,int rowNum) throws SQLException
			{
				User user = new User();
				user.setId(rs.getString("Id"));
				return user;
			}
		});
		
		if(list != null)
			return list.size();
		else
			return 0;
		*/
		Session session = getSession();
		Query<User> query = session.createQuery("from User where id = :id");
		query.setParameter("id",id);
		List<User> userlist = query.getResultList();
		if(userlist.size() > 0) {
			return userlist.size();
		} else {
			return 0;
		}
	}
	
	public boolean checkNowPassword(String Userid,String Password)
	{
		/*
		String sql = "select * from user where Id = ?";
		
		User user = template.queryForObject(sql,new Object[] {Userid},new RowMapper<User>() {
			public User mapRow(ResultSet rs,int rowNum) throws SQLException
			{
				User user = new User();
				user.setPassword((rs.getString("Password")));
				
				return user;
			}
		});

		if(passwordEncoder.matches(Password, user.getPassword()))
			return true;
		else
			return false;
		*/
		Session session = getSession();
		Query<User> query = session.createQuery("from User where id = :id");
		query.setParameter("id",Userid);
		User user = query.getSingleResult();
		if(passwordEncoder.matches(Password,user.getPassword())) {
			return true;
		} else {
			return false;
		}
	}
	
	public void updatePassword(String Userid,String Password)
	{
		/*
		String sql = "update user set Password = ? where Id = ?";
		template.update(sql,new Object[] {Password,Userid});
		*/
		Session session = getSession();
		Query query = session.createQuery("update User set password = :password where id = :id");
		query.setParameter("password",Password);
		query.setParameter("id",Userid);
		query.executeUpdate();
	}

	public void authorizingemailconfirm(String email) {
		Session session = getSession();
		Query query = session.createQuery("from User where email = :email");
		query.setParameter("email",email);
		User user = (User)(query.getSingleResult());
		Query query2 = session.createQuery("update User set emailconfirm = 1,enabled = 1 where id = :id");
		query2.setParameter("id",user.getId());
		query2.executeUpdate();
	}

	public boolean checkalreadyexistemail(String email) {
		Session session = getSession();
		Query query = session.createQuery("from User where email = :email");
		query.setParameter("email",email);
		List<User> user = query.getResultList();
		if(user.size() > 0) {
			return true;  //�̹� �̸����� �����ϴ� ������ ����
		} else {
			return false; //����
		}
	}

	public void joinnaveruser(User naveruser) {
		Session session = getSession();
		session.save(naveruser);
	}
}
