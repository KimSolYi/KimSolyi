package spring.myapp.shoppingmall.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;

import javax.sql.DataSource;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionTemplate;

import spring.myapp.shoppingmall.dto.Bookrecommend;
import spring.myapp.shoppingmall.dto.Coupon;
import spring.myapp.shoppingmall.dto.Goods;
import spring.myapp.shoppingmall.dto.Monthbook;
import spring.myapp.shoppingmall.dto.Order;
import spring.myapp.shoppingmall.dto.Ordergoods;
import spring.myapp.shoppingmall.dto.Recommend;
import spring.myapp.shoppingmall.dto.Refund;
import spring.myapp.shoppingmall.dto.Reply;
import spring.myapp.shoppingmall.dto.ReviewRecommend;
import spring.myapp.shoppingmall.dto.ReviewReply;
import spring.myapp.shoppingmall.dto.ReviewReplyRecommend;
import spring.myapp.shoppingmall.dto.Shoppingbasket;
import spring.myapp.shoppingmall.dto.Todaybook;
import spring.myapp.shoppingmall.dto.Usecoupon;
import spring.myapp.shoppingmall.dto.User;
import spring.myapp.shoppingmall.dto.Vbank;

@Repository
@Transactional
public class MallDao 
{
	private static final Logger logger = LoggerFactory.getLogger(MallDao.class);

	private JdbcTemplate template;
	
	@Autowired
	private SessionFactory sessionFactory;
	
	@Autowired(required=false)
	private TransactionTemplate transactionTemplate1;
	
	@Autowired
	public MallDao(DataSource dataSource) {
		this.template = new JdbcTemplate(dataSource);
	}
	
	//private Integer couponresult;
	//private Integer receivecoupon;
	
	private Session getSession() {
	    return sessionFactory.getCurrentSession();
	}
	
	public class GoodsMapper implements RowMapper<Goods>{  //물품 Mapper
		   public Goods mapRow(ResultSet rs, int rowNum) throws SQLException {
		      Goods good = new Goods();
		      good.setName(rs.getString("Name"));
			  good.setPrice(rs.getInt("Price"));
			  good.setGoodsprofile(rs.getString("goodsprofile"));
			  good.setKind(rs.getString("kind"));
			  good.setRemain(rs.getInt("remain"));
			  good.setId(rs.getInt("Id"));
			  good.setGoodscontent(rs.getString("goodscontent"));
		      good.setWriter(rs.getString("writer"));
			  good.setWcompany(rs.getString("wcompany"));
			  good.setTcontent(rs.getString("tcontent"));
			  good.setReview(rs.getString("review"));
			  good.setWriterintroduction(rs.getString("writerintroduction"));
			  good.setPage(rs.getInt("page"));
			  good.setSummary(rs.getString("summary"));
		      return good;
		   }
	}
	
	public class ShoppingbasketMapper implements RowMapper<Shoppingbasket>{  //장바구니 Mapper
		   public Shoppingbasket mapRow(ResultSet rs, int rowNum) throws SQLException {
		      Shoppingbasket shoppingbasket = new Shoppingbasket();
		      shoppingbasket.setPnum(rs.getInt("pnum"));
		      shoppingbasket.setGoods_id(rs.getInt("goods_id"));
		      shoppingbasket.setUser_id(rs.getString("user_id"));
		      shoppingbasket.setPrice(rs.getInt("price"));
		      shoppingbasket.setThumbnail(rs.getString("thumbnail"));
		      shoppingbasket.setQty(rs.getInt("qty"));
		      shoppingbasket.setName(rs.getString("name"));
		      return shoppingbasket;
		   }
	}
	
	public class OrderMapper implements RowMapper<Order>{  //고객의 주문 정보
		public Order mapRow(ResultSet rs,int rowNum) throws SQLException{
			Order order = new Order();
			order.setId(rs.getString("id"));
			order.setMerchant_id(rs.getString("merchant_id"));
			order.setPhoneNumber(rs.getString("phoneNumber"));
			order.setImp_uid(rs.getString("imp_uid"));
			order.setPaymethod(rs.getString("paymethod"));
			order.setPrice(rs.getInt("price"));
			order.setStatus(rs.getString("status"));
			order.setTime(rs.getTimestamp("time"));
			order.setTekbenumber(rs.getString("tekbenumber"));
			order.setAddress(rs.getString("address"));
			order.setCouponid(rs.getString("couponId"));
			order.setMemo(rs.getString("memo"));
			order.setName(rs.getString("name"));
			return order;
		}
	}
	
	public class OrderGoodsMapper implements RowMapper<Ordergoods>{  //주문물품 정보
		public Ordergoods mapRow(ResultSet rs,int rowNum) throws SQLException{
			Ordergoods ordergoods = new Ordergoods();
			ordergoods.setOrdergoodsnum(rs.getInt("ordergoodsnum"));
			ordergoods.setGoodsprofile(rs.getString("goodsprofile"));
			ordergoods.setMerchant_id(rs.getString("merchant_id"));
			ordergoods.setName(rs.getString("name"));
			ordergoods.setQty(rs.getInt("qty"));
			return ordergoods;
		}
	}
	
	public class CouponMapper implements RowMapper<Coupon>{  //쿠폰 정보
		public Coupon mapRow(ResultSet rs,int rowNum) throws SQLException{
			Coupon coupon = new Coupon();
			coupon.setId(rs.getString("Id"));
			coupon.setMaketime(rs.getTimestamp("maketime"));
			coupon.setUsecheck(rs.getString("usecheck"));
			coupon.setReceive(rs.getString("receive"));
			coupon.setType(rs.getInt("type"));
			coupon.setUser(rs.getString("user"));
			return coupon;
		}
	}
	
	public void insertMerchant(String id,String merchant_id,String phoneNumber,String address,String buyer_name,String memo,int price) {	//고객이 주문 결제 버튼을 누르는 순간 주문 아이디 DB에 넣기
		/*String sql = "insert into ordertable";
			   sql += "(id,merchant_id,status,phoneNumber,address,name,memo,price)"; 
			   sql += "values (?,?,?,?,?,?,?,?)";
		template.update(sql,new Object[] {id,merchant_id,"not paid",phoneNumber,address,buyer_name,memo,0});*/
		Session session = getSession();
		Order order = new Order();
		order.setId(id);
		order.setMerchant_id(merchant_id);
		order.setStatus("not paid");
		order.setPhoneNumber(phoneNumber);
		order.setAddress(address);
		order.setName(buyer_name);
		order.setMemo(memo);
		order.setPrice(price);
		order.setTime(new Timestamp(System.currentTimeMillis()));
		session.saveOrUpdate(order);
	}

	public void setShoppingbasket(int gid,String User_ID,int price,int qty,String name) {	//장바구니 담기 + 주문하기
		/*
		String sql = "select * from goods where Id = ?";
		Goods good;
		good = template.queryForObject(sql,new Object[] {gid},new GoodsMapper());
		sql = "insert into shoppingbasket";
		sql +="(goods_id,user_id,price,thumbnail,name,qty)";
		sql +="values (?,?,?,?,?,?)";
		template.update(sql,new Object[] {gid,User_ID,price,good.getGoodsprofile(),name,qty});
		*/ 
		Session session = getSession();
        Goods goods = (Goods)session.get(Goods.class,gid);
        Shoppingbasket shoppingbasket = new Shoppingbasket();
        shoppingbasket.setGoods_id(gid);
        shoppingbasket.setUser_id(User_ID);
        shoppingbasket.setPrice(price);
        shoppingbasket.setThumbnail(goods.getGoodsprofile());
        shoppingbasket.setName(name);
        shoppingbasket.setQty(qty);
        session.saveOrUpdate(shoppingbasket);
       // System.out.println("shoppingbasket 저장 완료");
	}
	
	public List<Shoppingbasket> getShoppingbasket(String User_ID){ 					//장바구니 담았던 물품 정보들 가져오기
		/*String sql = "select * from shoppingbasket where user_id = ?";
		List<Shoppingbasket> goods;
		goods = template.query(sql,new Object[]{User_ID},new ShoppingbasketMapper());
		return goods;*/
		Session session = getSession();
		Query<Shoppingbasket> query = session.createQuery("from Shoppingbasket where user_id= :user_id",Shoppingbasket.class);
		query.setParameter("user_id",User_ID);
		List<Shoppingbasket> Shoppingbasketlist = query.getResultList();
		System.out.println("Shoppinglist select 완료");
        return Shoppingbasketlist;
	}
	
	public Goods getGoodsInfo(int goods_id) { 							//하나의 물품 정보 확인
		/*
		String sql = "select * from goods where Id = ?";
		Goods good;
		good = template.queryForObject(sql,new Object[] {goods_id},new RowMapper<Goods>() {
			public Goods mapRow(ResultSet rs,int rowNum) throws SQLException{
				Goods good = new Goods();
				good.setName(rs.getString("Name"));
				good.setPrice(rs.getInt("Price"));
				good.setGoodsprofile(rs.getString("goodsprofile"));
				good.setKind(rs.getString("kind"));
				good.setRemain(rs.getInt("remain"));
				good.setId(rs.getInt("Id"));
				good.setGoodscontent(rs.getString("goodscontent"));
				good.setWriter(rs.getString("writer"));
				good.setWcompany(rs.getString("wcompany"));
				good.setTcontent(rs.getString("tcontent"));
				good.setReview(rs.getString("review"));
				good.setWriterintroduction(rs.getString("writerintroduction"));
				good.setPage(rs.getInt("page"));
				good.setSummary(rs.getString("summary"));
				
				return good;
			}
		});
		return good;
		*/
		/*Session session = sessionFactory.getCurrentSession();
		Goods goods = (Goods)session.get(Goods.class,goods_id);
		return goods;*/
		Session session = getSession();
		//Query<Goods> query = session.createQuery("from Goods where id = :id",Goods.class);
		//query.setParameter("id",goods_id);
		Goods goods = session.get(Goods.class,goods_id);//query.getSingleResult();
        return goods;
	}
	
	public List<Goods> getShoppingGoodsInfo(String kind) { 							//하나의 물품 종류에 대하여 모든 물품을 가져옴 
		String sql = "select * from goods where kind = ?";
		List<Goods> goods;
		goods = template.query(sql,new Object[] {kind},new RowMapper<Goods>() {
			public Goods mapRow(ResultSet rs,int rowNum) throws SQLException{
				Goods good = new Goods();
				good.setName(rs.getString("Name"));
				good.setPrice(rs.getInt("Price"));
				good.setGoodsprofile(rs.getString("goodsprofile"));
				good.setRemain(rs.getInt("remain"));
				
				return good;
			}
		});
		return goods;
	}
	/*
	public void uploadgoods(String thumbnail,String name,int price,String kind,int remain,String content,String writer,String wcompany
			,String tcontent,String writerintroduce,String summary,String review,int page,String bigclass,String subclass) {
		String sql = "insert into goods (goodsprofile,name,price,kind,remain,goodscontent,writer,wcompany,tcontent,writerintroduction,summary,review,page,bigclass,subclass) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	    if(content.contains("\r\n"))
	    	content = content.replace("\r\n","<br>");
	    if(tcontent!= null && tcontent.contains("\r\n"))
	    	tcontent = tcontent.replace("\r\n","<br>");
	    if(writerintroduce!= null && writerintroduce.contains("\r\n"))
	    	writerintroduce = writerintroduce.replace("\r\n","<br>");
	    if(summary!= null && summary.contains("\r\n"))
	    	summary = summary.replace("\r\n","<br>");
	    if(review!= null && review.contains("\r\n"))
	    	review = review.replace("\r\n","<br>");
	    
		template.update(sql,new Object[] {thumbnail,name,price,kind,remain,content,writer,wcompany,tcontent,writerintroduce,summary,review,page,bigclass,subclass});
	}
	*/
	
	public void uploadgoods(Goods goods) {
		//String sql = "insert into goods (goodsprofile,name,price,kind,remain,goodscontent,writer,wcompany,tcontent,writerintroduction,summary,review,page,bigclass,subclass) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	    Session session = getSession();
	    if(goods.getGoodscontent().contains("\r\n"))
	    	goods.setGoodscontent(goods.getGoodscontent().replace("\r\n","<br>"));
	    if(goods.getTcontent() != null && goods.getTcontent().contains("\r\n"))
	    	goods.setTcontent(goods.getTcontent().replace("\r\n","<br>"));
	    if(goods.getWriterintroduction() != null && goods.getWriterintroduction().contains("\r\n"))
	    	goods.setWriterintroduction(goods.getWriterintroduction().replace("\r\n","<br>"));
	    if(goods.getSummary() != null && goods.getSummary().contains("\r\n"))
	    	goods.setSummary(goods.getSummary().replace("\r\n","<br>"));
	    if(goods.getReview() != null && goods.getReview().contains("\r\n"))
	    	goods.setReview(goods.getReview().replace("\r\n","<br>"));
	    session.save(goods);
		//template.update(sql,new Object[] {goods.getGoodsprofile(),goods.getName(),goods.getPrice(),goods.getKind(),goods.getRemain(),goods.getGoodscontent(),goods.getWriter(),goods.getWcompany(),goods.getTcontent(),goods.getWriterintroduction(),goods.getSummary(),goods.getReview(),goods.getPage(),goods.getBigclass(),goods.getSubclass()});
	}
	
	
	public void uploadProfilegoods(int goods_id,String uploadurl) {    //이미 등록되어 있는 물품의 프로필을 등록
		//String sql = "update goods set goodsprofile = ? where Id = ?";
		//template.update(sql,new Object[] {uploadurl,goods_id});
		Session session = getSession();
		Query query = session.createQuery("update Goods set goodsprofile = :goodsprofile where id = :id");
		query.setParameter("goodsprofile",uploadurl);
		query.setParameter("id",goods_id);
		query.executeUpdate();
	}

	/////////////////////////////////////////페이징 처리///////////////////////////////////////////
	public List<Goods> getsearchinfo(int curPageNum,String search,String subject){
		if(search == "") {
			return null;
		}
		search = search.trim();
		/*
		if(search.contains("'") || search.contains(" "))
		{
			search = search.replace("'","");
			search = search.replace(" ","");
		}
		*/
		System.out.println("search : " + search);
		/*
		String sql = "select R1.* FROM( SELECT * FROM goods where name like '%" + search + "%' order by Id asc) R1 LIMIT ?, ?";
		List<Goods> goods = null;
		goods = template.query(sql,new Object[] {6 * (curPageNum - 1),6},new RowMapper<Goods>() {
			public Goods mapRow(ResultSet rs,int rowNum) throws SQLException{
				Goods good = new Goods();
				good.setId(rs.getInt("Id"));
				good.setName(rs.getString("Name"));
				good.setPrice(rs.getInt("Price"));
				good.setGoodsprofile(rs.getString("goodsprofile"));
				good.setRemain(rs.getInt("remain"));
				good.setKind(rs.getString("kind"));
				
				return good;
			}
		});
		return goods;
		*/
		Session session = getSession();
		if(subject.equals("name")) {
			Query<Goods> query = session.createQuery("from Goods where name like '%" + search + "%' order by id asc",Goods.class);
			query.setFirstResult(6 * (curPageNum - 1)).setMaxResults(6);
			return query.getResultList();
		} else if(subject.equals("writer")) {
			Query<Goods> query = session.createQuery("from Goods where writer like '%" + search + "%' order by id asc",Goods.class);
			query.setFirstResult(6 * (curPageNum - 1)).setMaxResults(6);
			return query.getResultList();
		} else {
			Query<Goods> query = session.createQuery("from Goods where wcompany like '%" + search + "%' order by id asc",Goods.class);
			query.setFirstResult(6 * (curPageNum - 1)).setMaxResults(6);
			return query.getResultList();
		}
	}
	
	public int getCountKwd(String subject,String search) {
		if(search == "") {
			return 1;
		}
		search = search.trim();
		/*
		if(search.contains("'") || search.contains(" ")){
			search = search.replace("'","");
			search = search.replace(" ","");
		}
		*/
		/*
		String sql = "select * from goods where name like '%" + search + "%'";
		List<Goods> goods = null;
		goods = template.query(sql,new RowMapper<Goods>() {
			public Goods mapRow(ResultSet rs,int rowNum) throws SQLException{
				Goods good = new Goods();
				good.setId(rs.getInt("Id"));
				return good;
			}
		});
		return goods.size();
		*/
		Session session = getSession();
		if(subject.equals("name")) {
			Query<Goods> query = session.createQuery("from Goods where name like '%" + search + "%'");
			return query.getResultList().size();
		} else if(subject.equals("writer")) {
			Query<Goods> query = session.createQuery("from Goods where writer like '%" + search + "%'");
			return query.getResultList().size();
		} else{
			Query<Goods> query = session.createQuery("from Goods where wcompany like '%" + search + "%'");
			return query.getResultList().size();
		}
	}
	
	public List<Goods> getCurPageDtos(int curPageNum,String kind) {
		String sql = "select R1.* FROM( SELECT * FROM goods where kind = ? order by Id asc) R1 LIMIT ?, ?";   
		List<Goods> goods = null;
		goods = template.query(sql,new Object[] {kind,6 * (curPageNum - 1),6},new RowMapper<Goods>() { // 6 * (curPageNum -1 )
			public Goods mapRow(ResultSet rs,int rowNum) throws SQLException{
				Goods good = new Goods();
				good.setId(rs.getInt("Id"));
				good.setName(rs.getString("Name"));
				good.setPrice(rs.getInt("Price"));
				good.setGoodsprofile(rs.getString("goodsprofile"));
				good.setRemain(rs.getInt("remain"));
				good.setKind(rs.getString("kind"));
				
				return good;
			}
		});
		return goods;
	}
	
	public List<Goods> getCurPageDtosWithBook(int curPageNum, String bigclass, String subclass) {
		/*String sql = "select R1.* FROM( SELECT * FROM goods where bigclass = ? and subclass = ? order by Id asc) R1 LIMIT ?,?";   
		List<Goods> goods = null;
		goods = template.query(sql,new Object[] {bigclass,subclass,6 * (curPageNum - 1),6},new RowMapper<Goods>() { // 6 * (curPageNum -1 )
			public Goods mapRow(ResultSet rs,int rowNum) throws SQLException{
				Goods good = new Goods();
				good.setId(rs.getInt("Id"));
				good.setName(rs.getString("Name"));
				good.setPrice(rs.getInt("Price"));
				good.setGoodsprofile(rs.getString("goodsprofile"));
				good.setRemain(rs.getInt("remain"));
				good.setKind(rs.getString("kind"));
				good.setBigclass(rs.getString("bigclass"));
				good.setSubclass(rs.getString("subclass"));
				
				return good;
			}
		});
		return goods;*/
		Session session = getSession();
		Query<Goods> query = session.createQuery("from Goods where bigclass = :bigclass and subclass = :subclass",Goods.class);
		query.setFirstResult(6 * (curPageNum - 1)).setMaxResults(6);
		query.setParameter("bigclass",bigclass);
		query.setParameter("subclass",subclass);
		List<Goods> goodslist = query.getResultList(); 
        return goodslist;
	}
	
	
	public int getCount(String kind) 
	{
		String sql = "select * from goods where kind = ?";
		List<Goods> goods = null;
		goods = template.query(sql,new Object[] {kind},new RowMapper<Goods>() {
			public Goods mapRow(ResultSet rs,int rowNum) throws SQLException{
				Goods good = new Goods();
				good.setId(rs.getInt("Id"));
				return good;
			}
		});
		return goods.size();
	}
	
	public int getCountWithBook(String bigclass, String subclass) {
		/*String sql = "select * from goods where bigclass = ? and subclass = ?";
		List<Goods> goods = null;
		goods = template.query(sql,new Object[] {bigclass,subclass},new RowMapper<Goods>() {
			public Goods mapRow(ResultSet rs,int rowNum) throws SQLException{
				Goods good = new Goods();
				good.setId(rs.getInt("Id"));
				return good;
			}
		});
		return goods.size();*/
		
        Session session  = getSession();
		Query<Goods> query = session.createQuery("from Goods where bigclass = :bigclass and subclass = :subclass",Goods.class);
		query.setParameter("bigclass",bigclass);
		query.setParameter("subclass",subclass);
		List<Goods> goodslist = query.getResultList();
		return goodslist.size();
	}
	
	public int getCountOrder(String id) {
		/*
		String sql = "select * from ordertable where id = ?";
		List<Order> orders = null;
		orders = template.query(sql,new Object[] {id},new RowMapper<Order>() {
			public Order mapRow(ResultSet rs,int rowNum) throws SQLException{
				Order order = new Order();
				order.setId(rs.getString("id"));
				return order;
			}
		});
		return orders.size();
		*/
		Session session = getSession();
		Query<Order> orders = session.createQuery("from Order where id = :id");
		orders.setParameter("id",id);
		List<Order> orderlist = orders.getResultList();
		return orderlist.size();
	}

	public void deletebasket(int pnum) {
		/*
		String sql = "delete from shoppingbasket where pnum = ?";
		template.update(sql,new Object[] {pnum});
		*/
		Session session = getSession();
		Query query = session.createQuery("delete from Shoppingbasket where pnum = :pnum");
		query.setParameter("pnum",pnum);
		query.executeUpdate();
	}
	public void insertPrice(int price,String merchant_uid) {
	 //transactionTemplate1.execute(new TransactionCallbackWithoutResult() {
		//@Override
		// protected void doInTransactionWithoutResult(TransactionStatus status) {
		//String sql = "update ordertable set price = ? where merchant_id = ?";
		//template.update(sql,new Object[] {price,merchant_uid});
		Session session = getSession();	
		Query query = session.createQuery("update Order set price = :price where merchant_id = :merchant_id");
		query.setParameter("price",price);
		query.setParameter("merchant_id",merchant_uid);
		query.executeUpdate();
		logger.info("insertPrice 메소드 성공");
		 //}
	 //});
	}
	
	public int getfindprice(String merchant_uid) {
		/*
		String sql = "select * from ordertable where merchant_id = ?";
		int price;
		Order order;
		order = template.queryForObject(sql,new Object[] {merchant_uid},new RowMapper<Order>() {
			public Order mapRow(ResultSet rs,int rowNum) throws SQLException{
				Order order = new Order();
				order.setPrice(rs.getInt("price"));
				
				return order;
			}
		});
		
		return order.getPrice();
		*/
		
		/*  orderid pk 설정값 바꾼 이후
		Session session = getSession();
		Order order = session.get(Order.class,merchant_uid);
		return order.getPrice();
		*/
		Session session = getSession();
		Query query = session.createQuery("from Order where merchant_id = :merchant_id");
		query.setParameter("merchant_id",merchant_uid);
		Order order = (Order)query.getSingleResult();
		return order.getPrice();
	}
	
	public void statusupdate(String updatestatus,String merchant_uid,String imp_uid,String paymethod) {
	  //transactionTemplate1.execute(new TransactionCallbackWithoutResult(){
		//@Override
		//protected void doInTransactionWithoutResult(TransactionStatus status) {
		
		/*
			if(imp_uid != null)
			{	
				String sql = "update ordertable set status = ?,imp_uid = ?,paymethod = ? where merchant_id = ?";	//결제 완료
				template.update(sql,new Object[] {updatestatus,imp_uid,paymethod,merchant_uid}); 
			}
			else
			{
				String sql = "update ordertable set status = ? where merchant_id = ?"; //결제 미완료 ex)무통장 입금
				template.update(sql,new Object[] {updatestatus,merchant_uid});
			}
		*/
		Session session = getSession();
			if(imp_uid != null) {
				Query query = session.createQuery("update Order set status = :status,imp_uid = :imp_uid,paymethod = :paymethod where merchant_id = :merchant_id");
				query.setParameter("status",updatestatus);
				query.setParameter("imp_uid",imp_uid);
				query.setParameter("paymethod",paymethod);
				query.setParameter("merchant_id",merchant_uid);
				query.executeUpdate();
			} else {
				Query query = session.createQuery("update Order set status = :status where merchant_id = :merchant_id");
				query.setParameter("status",updatestatus);
				query.setParameter("merchant_id",merchant_uid);
				query.executeUpdate();
			}
			logger.info("statusupdate 메소드 성공");
		//}
	 //});
	}
	
	public Order getMerchantid(String merchant_id) {
		/*
		String sql = "select * from ordertable where merchant_id = ?";
		Order order = null;
			try {
					order = template.queryForObject(sql,new Object[] {merchant_id},new RowMapper<Order>() {
						public Order mapRow(ResultSet rs,int rowNum) throws SQLException {
							Order order = new Order();
							order.setMerchant_id(rs.getString("merchant_id"));
							order.setPrice(rs.getInt("price"));
							order.setStatus(rs.getString("status"));
			
							return order;
						}
					});
				}catch (Exception e) {
					order = null;
				}
				return order;
			*/
			
			/* orderid pk 값 바꾼 이후
			Session session = getSession();
			Order order = session.get(Order.class,merchant_id);
			logger.info("Order값 확인 : {}",order);
			return order;
			*/
			Session session = getSession();
			Query query = session.createQuery("from Order where merchant_id = :merchant_id");
			query.setParameter("merchant_id",merchant_id);
			Order order = (Order)query.getSingleResult();
			logger.info("Order값 확인 : {}",order);
			return order;
	}
	
	public String getimp_uid(String merchant_uid) {
		/*
		String sql = "select * from ordertable where merchant_id = ?";
		Order order = null;
		order = template.queryForObject(sql, new Object[] {merchant_uid},new RowMapper<Order>() {
			public Order mapRow(ResultSet rs,int rowNum) throws SQLException {
				Order order = new Order();
				order.setImp_uid(rs.getString("imp_uid"));
				
				return order;
			}
		});
		return order.getImp_uid();
		*/
		
		/* orderid pk로 바꾼 이후
		Session session = getSession();
		Order order = session.get(Order.class,merchant_uid);
		return order.getImp_uid();
		*/
		Session session = getSession();
		Query query = session.createQuery("from Order where merchant_id = :merchant_id");
		query.setParameter("merchant_id",merchant_uid);
		Order order = (Order)query.getSingleResult();
		return order.getImp_uid();
	}
	
	public void deltemerchantid(String merchant_id) {
		/*
		String sql = "delete from ordertable where merchant_id = ?";
		template.update(sql,new Object[] {merchant_id});
		*/
		Session session = getSession();
		Query query = session.createQuery("delete from Order where merchant_id = :merchant_id");
		query.setParameter("merchant_id",merchant_id);
		query.executeUpdate();
	}
	
	public void statusupdatecancel(String merchant_id, String cancel) {
		/*
		String sql = "update ordertable set status = ? where merchant_id = ?";
		template.update(sql,new Object[] {cancel,merchant_id});
		*/
		Session session = getSession();
		Query query = session.createQuery("update Order set status = :status where merchant_id = :merchant_id");
		query.setParameter("status",cancel);
		query.setParameter("merchant_id",merchant_id);
		query.executeUpdate();
		query = session.createQuery("update Refund set status = :status where merchant_id = :merchant_id");
		query.setParameter("status","finished");
		query.setParameter("merchant_id",merchant_id);
		query.executeUpdate();
	}
	
	public void insertvbank(String merchant_id, String vbanknum, String vbankname, String vbankdate,
			String vbankholder,String vbankperson,String vbankcode) {
		/*
		String sql = "insert into vbank (merchant_id,vbanknum,vbankname,vbankdate,vbankholder,vbankperson,vbankcode) values (?,?,?,?,?,?,?)";
		template.update(sql,new Object[] {merchant_id,vbanknum,vbankname,vbankdate,vbankholder,vbankperson,vbankcode});
		*/
		Session session = getSession();
		Vbank vbank = new Vbank();
		vbank.setMerchant_id(merchant_id);
		vbank.setVbanknum(vbanknum);
		vbank.setVbankname(vbankname);
		vbank.setVbankdate(vbankdate);
		vbank.setVbankholder(vbankholder);
		vbank.setVbankperson(vbankperson);
		vbank.setVbankcode(vbankcode);
		session.saveOrUpdate(vbank);
		logger.info("insertvbank 메소드 성공");
	}
	
	public void insertgoods(String merchant_id, String[] booknamelist, Integer[] bookqtylist) {
	 //transactionTemplate1.execute(new TransactionCallbackWithoutResult() {
		//@Override
		//protected void doInTransactionWithoutResult(TransactionStatus status) {
		/*String sql = null;
		String sql2 = null;
		System.out.println("list : " + list);
		System.out.println("glist : " + glist);
		System.out.println("list size : " + list.length);
		String name;
		int g;
		
			for(int i = 0; i < list.length; i++) {
				sql = "insert into ordergoods (merchant_id,name,qty) values (?,?,?)";  //주문 물품에 대한 DB insert
				name = list[i];  //물품명
				g = glist[i];    //물품의 갯수
				template.update(sql,new Object[] {merchant_id,name,g});
				sql = "select * from goods where name = ?";  //주문 물품에 대한 물품의 정보를 가져오기
				Goods good = null;
				good = template.queryForObject(sql,new Object[] {name},new RowMapper<Goods>() {
					public Goods mapRow(ResultSet rs,int  rowNum) throws SQLException{
						Goods good = new Goods();
						good.setGoodsprofile(rs.getString("goodsprofile"));
						return good;
					}
				});
				sql = "update ordergoods set goodsprofile = ? where name = ?";  //물품 테이블에서 가져온 물품의 프로필 사진을 주문 물품의 사진 컬럼에 insert 하기
				template.update(sql,new Object[] {good.getGoodsprofile(),name});
				*/
				//sql = "update goods set remain = " + (good.getRemain() - glist[i]) + " where name = ?";  //주문한 물품만큼 물품 테이블에서 남은 갯수를 빼기
				//template.update(sql,new Object[] {list[i]});  		-->이 코드 두줄 포함하기 밑에껀 빼도록...
			//}
		
		/*
			for(int j=0; j<list.length;j++) {
				sql = "select * from goods where name = ?";  //주문 물품의 정보를 다시 가져오기
				Goods good;
				good = template.queryForObject(sql,new Object[] {list[j]},new RowMapper<Goods>() {
					public Goods mapRow(ResultSet rs,int rowNum) throws SQLException{
						Goods good = new Goods();
						good.setRemain(rs.getInt("remain"));
					
						return good;
					}
				});
			
			sql = "update goods set remain = " + (good.getRemain() - glist[j]) + " where name = ?";  //주문한 물품만큼 물품 테이블에서 남은 갯수를 빼기
			template.update(sql,new Object[] {list[j]});
		}*/
	   //}
	 //});
		String name;
		int qty;
		Session session = getSession();
			for(int i = 0; i < booknamelist.length; i++) {
				name = booknamelist[i];  //물품명
				qty = bookqtylist[i];    //물품의 갯수
				Ordergoods ordergoods = new Ordergoods();
				ordergoods.setMerchant_id(merchant_id);
				ordergoods.setName(name);
				ordergoods.setQty(qty);
				Query orderselectbymerchantidquery = session.createQuery("from Order where merchant_id = :merchant_id");
				orderselectbymerchantidquery.setParameter("merchant_id",merchant_id);
				Order order = (Order)orderselectbymerchantidquery.getSingleResult();
				ordergoods.setOrderid(order); //ManyToOne
				session.saveOrUpdate(ordergoods);
				Query<Goods> query = session.createQuery("from Goods where name = :name",Goods.class);   
				query.setParameter("name",name);
				Goods goods = query.getSingleResult();
				Query query2 = session.createQuery("update Ordergoods set goodsprofile = :goodsprofile where name = :name");
				query2.setParameter("goodsprofile",goods.getGoodsprofile());
				query2.setParameter("name",goods.getName());
				query2.executeUpdate();
				Query query3 = session.createQuery("update Goods set remain = :remain where name = :name");
				query3.setParameter("remain",goods.getRemain() - bookqtylist[i]);
				query3.setParameter("name",booknamelist[i]);
				query3.executeUpdate();
			}
			for(int j=0; j<booknamelist.length;j++) {
				Query<Goods> query4 = session.createQuery("from Goods where name = :name",Goods.class);
				query4.setParameter("name",booknamelist[j]);
				Goods goods = query4.getSingleResult();
				Query query5 = session.createQuery("update Goods set remain = :remain where name = :name");
				query5.setParameter("remain",goods.getRemain() - bookqtylist[j]);
				query5.setParameter("name",booknamelist[j]);
				query5.executeUpdate();
				Query query6 = session.createQuery("update Goods set purchase = purchase + " + bookqtylist[j] +" where id = :id");
				query6.setParameter("id",goods.getId());
				query6.executeUpdate();
			}
			logger.info("무통장 입금 이외 결제 - insertgoods 메소드 성공");
	}
	
	public void insertVbankgoods(String merchant_id, String[] booknamelist, Integer[] bookqtylist) {
	/*
	 transactionTemplate1.execute(new TransactionCallbackWithoutResult() {
		@Override
		protected void doInTransactionWithoutResult(TransactionStatus status) {
		String sql = null;
		String sql2 = null;
		System.out.println("list : " + list);
		System.out.println("glist : " + glist);
		System.out.println("list size : " + list.length);
		String name;
		int g;
		
			for(int i = 0; i < list.length; i++) {
				sql = "insert into ordergoods (merchant_id,name,qty) values (?,?,?)";
				name = list[i];
				g = glist[i];
				template.update(sql,new Object[] {merchant_id,name,g});
				sql = "select * from goods where name = ?";
				Goods good = null;
				good = template.queryForObject(sql,new Object[] {name},new RowMapper<Goods>() {
					public Goods mapRow(ResultSet rs,int  rowNum) throws SQLException{
						Goods good = new Goods();
						good.setGoodsprofile(rs.getString("goodsprofile"));
						return good;
					}
				});
			
			sql = "update ordergoods set goodsprofile = ? where name = ?";
			template.update(sql,new Object[] {good.getGoodsprofile(),name});
		}
		}
	 });
	 */
		String name;
		int qty;
		Session session = getSession();
		for(int i = 0; i < booknamelist.length; i++) {
			name = booknamelist[i];
			qty = bookqtylist[i];
			Ordergoods ordergoods = new Ordergoods();
			ordergoods.setMerchant_id(merchant_id);
			ordergoods.setName(name);
			ordergoods.setQty(qty);
			session.saveOrUpdate(ordergoods);
			Query<Goods> query = session.createQuery("from Goods where name = :name",Goods.class);
			query.setParameter("name",name);
			Goods good = query.getSingleResult();
			String hql = "update Ordergoods set goodsprofile = :goodsprofile where name = :name";
			Query query2 = session.createQuery(hql);
			query2.setParameter("goodsprofile",good.getGoodsprofile());
			query2.setParameter("name",name);
			query2.executeUpdate();
		}
		logger.info("insertVbankgoods 메소드 성공");
	}
	
	public void subordergoodsVbank(String merchant_uid) {
		/*
		String sql = "select * from ordergoods where merchant_id = ?";
		List<Ordergoods> ordergoods = null;
		ordergoods = template.query(sql,new Object[] {merchant_uid},new RowMapper<Ordergoods>() {
			public Ordergoods mapRow(ResultSet rs,int RowNum) throws SQLException {
				Ordergoods ordergoods = new Ordergoods();
				ordergoods.setName(rs.getString("name"));
				ordergoods.setQty(rs.getInt("qty"));
				return ordergoods;
			}
		});
		
			for(int j=0; j<ordergoods.size();j++) {
				sql = "select * from goods where name = ?";
				Goods good;
				good = template.queryForObject(sql,new Object[] {ordergoods.get(j).getName()},new RowMapper<Goods>() {
					public Goods mapRow(ResultSet rs,int rowNum) throws SQLException{
						Goods good = new Goods();
						good.setRemain(rs.getInt("remain"));
					
						return good;
					}
				});
			
			sql = "update goods set remain = " + (good.getRemain() - ordergoods.get(j).getQty()) + " where name = ?";
			template.update(sql,new Object[] {ordergoods.get(j).getName()});
		}
		*/
		
		Session session = getSession();
		Query<Ordergoods> query = session.createQuery("from Ordergoods where merchant_id = :merchant_id",Ordergoods.class);
		query.setParameter("merchant_id",merchant_uid);
		List<Ordergoods> ordergoodslist = query.getResultList();
		for(int j=0; j < ordergoodslist.size();j++) {
			Query<Goods> query2 = session.createQuery("from Goods where name = :name",Goods.class);
			query2.setParameter("name",ordergoodslist.get(j).getName());
			Goods goods = query2.getSingleResult();
			Query query3 = session.createQuery("update Goods set remain = :remain where name = :name");
			query3.setParameter("remain",goods.getRemain() - ordergoodslist.get(j).getQty());
			query3.setParameter("name",ordergoodslist.get(j).getName());
			query3.executeUpdate();
			Query query4 = session.createQuery("update Goods set purchase = purchase + " 
					+ ((Ordergoods)(ordergoodslist.get(j))).getQty()
					+ " where id = :id");
			query4.setParameter("id",goods.getId());
			query4.executeUpdate();
		}
	}
	
	public List<Order> getorderinfo(String id,int curPageNum) {
		//String sql = "select *,DATE_ADD(time, INTERVAL 9 Hour) from ordertable where id = ? order by time desc LIMIT ?,?";
		/*
		String sql = "select * from ordertable where id = ? order by time desc LIMIT ?,?";
		List<Order> orders = null;
		
		orders = template.query(sql,new Object[] {id,6 * (curPageNum - 1),6},new RowMapper<Order>() {
			public Order mapRow(ResultSet rs,int rowNum) throws SQLException{
				Order order = new Order();
				order.setId(rs.getString("id"));
				order.setMerchant_id(rs.getString("merchant_id"));
				order.setPrice(rs.getInt("price"));
				order.setStatus(rs.getString("status"));
				order.setTekbenumber(rs.getString("tekbenumber"));
				order.setPaymethod(rs.getString("paymethod"));
				order.setAddress(rs.getString("address"));
				order.setTime(rs.getTimestamp("time"));
				//order.setTime(rs.getTimestamp("DATE_ADD(time, INTERVAL 9 Hour)"));
				
				return order;
			}
		});
		return orders;
		*/
		Session session = getSession();
		Query<Order> query = session.createQuery("from Order where id = :id order by time desc");
		query.setParameter("id",id);
		query.setFirstResult(6 * (curPageNum -1)).setMaxResults(6);
		List<Order> orderlist = query.getResultList();
		return orderlist;
	}
	public List<Ordergoods> getordergoods(String merchant_id) {
		/*
		String sql = "select * from ordergoods where merchant_id = ?";
		List<Ordergoods> ordergoods = null;
		
		ordergoods = template.query(sql,new Object[] {merchant_id},new RowMapper<Ordergoods>() {
			public Ordergoods mapRow(ResultSet rs,int rowNum) throws SQLException{
				Ordergoods ordergoods = new Ordergoods();
				ordergoods.setName(rs.getString("name"));
				ordergoods.setQty(rs.getInt("qty"));
				ordergoods.setMerchant_id(rs.getString("merchant_id"));
				ordergoods.setGoodsprofile(rs.getString("goodsprofile"));
				
				return ordergoods;
			}
		});
		return ordergoods;
		*/
		Session session = getSession();
		Query<Ordergoods> query = session.createQuery("from Ordergoods where merchant_id = :merchant_id",Ordergoods.class);
		query.setParameter("merchant_id",merchant_id);
		List<Ordergoods> ordergoodslist = query.getResultList();
		return ordergoodslist;
	}
	public Vbank getvbankinfo(String merchant_id){
		/*
		String sql = "select * from vbank where merchant_id = ?";
		Vbank vbank = null;
		try 
		{	
			vbank = template.queryForObject(sql,new Object[] {merchant_id},new RowMapper<Vbank>() {
				public Vbank mapRow(ResultSet rs,int rowNum) throws SQLException{
					Vbank vbank = new Vbank();
					vbank.setMerchant_id(rs.getString("merchant_id"));
					vbank.setVbankname(rs.getString("vbankname"));
					vbank.setVbankdate(rs.getString("vbankdate"));
					vbank.setVbanknum(rs.getString("vbanknum"));
					vbank.setVbankholder(rs.getString("vbankholder"));
					vbank.setVbankperson(rs.getString("vbankperson"));
					vbank.setVbankcode(rs.getString("vbankcode"));
				
					return vbank;
				}
			});
		}catch(Exception e) {
		 vbank = new Vbank();
		}
	 		return vbank;
	 	*/
		//0개인 경우 1개인 경우 2개 이상인경우...
		Session session = getSession();
		Query<Vbank> query = session.createQuery("from Vbank where merchant_id = :merchant_id",Vbank.class);
		query.setParameter("merchant_id",merchant_id);
		List<Vbank> vbanklist = query.getResultList();
		if(vbanklist.size() == 0) {
			return new Vbank();
		} else {
			Vbank vbank = query.getSingleResult();
			return vbank;
		}
	}
	
	public void requestrefund(String merchant_id, Integer amount, String holder, String bank, String account) {
		/*
		String sql = "insert into requestrefund (merchant_id,amount,refund_holder,refund_bank,refund_account) values (?,?,?,?,?)";
		template.update(sql,new Object[] {merchant_id,amount,holder,bank,account});
		*/
		Session session = getSession();
		logger.info("requestrefund 메소드 실행");
		Refund requestrefund = new Refund();
		requestrefund.setMerchant_id(merchant_id);
		requestrefund.setAmount(amount);
		requestrefund.setRefundholder(holder);
		requestrefund.setRefundbank(bank);
		requestrefund.setRefundaccount(account);
		requestrefund.setStatus("in progress");
		Query query = session.createQuery("from Order where merchant_id = :merchant_id");
		query.setParameter("merchant_id",merchant_id);
		logger.info("requestrefund 메소드 실행2");
		Order order = (Order)query.getSingleResult();
		logger.info("order : {}",order);
		requestrefund.setOrderid(order);
		logger.info("requestrefund 메소드 실행3");
		session.save(requestrefund);
	}
	
	public Refund getrefund(String merchant_id) {
		/*
		String sql = "select * from requestrefund where merchant_id = ?";
		Refund refund = null;
		try {
				refund = template.queryForObject(sql,new Object[] {merchant_id},new RowMapper<Refund>() {
					public Refund mapRow(ResultSet rs,int rowNum) throws SQLException{
						Refund refund = new Refund();
						refund.setMerchant_id(rs.getString("merchant_id"));
						refund.setAmount(rs.getInt("amount"));
						refund.setRefundaccount(rs.getString("refund_account"));
						refund.setRefundbank(rs.getString("refund_bank"));
						refund.setRefundholder(rs.getString("refund_holder"));
				
						return refund;
					}
				});
			}catch(Exception e) {
				return null;
		}
		return refund;
		*/
		Session session = getSession();
		Query<Refund> query = session.createQuery("from Refund where merchant_id = :merchant_id");
		query.setParameter("merchant_id",merchant_id);
		List<Refund> refundlist = query.getResultList();
		if(refundlist.size() > 0) {
			return refundlist.get(0);
		} else {
			return null;
		}
	}
	
	public int remaincheck(String[] newname, Integer[] newqty) {
		/*
		String sql = null;
		Goods good = null;
		
			for(int i=0;i<newname.length;i++) {
				sql = "select * from goods where name = ?";
					good = template.queryForObject(sql,new Object[] {newname[i]},new RowMapper<Goods>() {
						public Goods mapRow(ResultSet rs,int rowNum) throws SQLException{
							Goods good = new Goods();
							good.setRemain(rs.getInt("remain"));
							return good;
						}
					});
					if(good.getRemain() < newqty[i])		//return 0 이면 실패, return 1이면 성공
						return 0;
			}
		return 1;
		*/
		Session session = getSession();
		Query query = null;
		for(int i=0;i<newname.length;i++) {
			query = session.createQuery("from Goods where name = :name");
			query.setParameter("name",newname[i]);
			Goods good = (Goods)query.getSingleResult();
			if(good.getRemain() < newqty[i]) {
				return 0;
			}
		} 
		return 1;
	}
	
	public int cartspace(String Id) {
		/*String sql = "select * from shoppingbasket where user_id = ?";
		List<Shoppingbasket> carts = null;
		
			try {
				carts = template.query(sql,new Object[] {Id},new RowMapper<Shoppingbasket>() {
					public Shoppingbasket mapRow(ResultSet rs,int rowNum) throws SQLException {
						Shoppingbasket basket = new Shoppingbasket();
						basket.setUser_id(rs.getString("user_id"));
						return basket;
					}
				});
			} catch(Exception e) {
				return carts.size();
			}
		
		return carts.size();*/
		Session session = getSession();
		Query<Shoppingbasket> query = session.createQuery("from Shoppingbasket where user_id='"+Id+"'",Shoppingbasket.class);
		List<Shoppingbasket> goodslist = query.getResultList(); 
        return goodslist.size();
	}

	public void rollbackdeletemerchantid(String merchant_id) {
		/*
		String sql = "delete from ordertable where merchant_id = ?";
		template.update(sql,new Object[] {merchant_id});
		*/
		Session session = getSession();
		Query query = session.createQuery("delete from Order where merchant_id = :merchant_id");
		query.setParameter("merchant_id",merchant_id);
		query.executeUpdate();
	}
	
	public Integer usecoupon(String cnumber) {
	 //transactionTemplate1.execute(new TransactionCallbackWithoutResult() {
		 //@Override
		 //protected void doInTransactionWithoutResult(TransactionStatus status) {
		  //try {
			 /*String sql = "select * from coupon where Id = ?";
			 Coupon coupon = null;
			 	try {
			 		coupon = template.queryForObject(sql,new Object[] {cnumber},new RowMapper<Coupon>() {
			 			public Coupon mapRow(ResultSet rs,int Rownum) throws SQLException {
			 				Coupon coupon = new Coupon();
			 				coupon.setType(rs.getInt("type"));
			 				coupon.setUsecheck(rs.getString("usecheck"));
			 				return coupon;
			 			}
			 		});
			 	} catch(Exception e){
			 		couponresult = 10;
			 	}
			 */
			  /*
			 if(coupon != null && coupon.getUsecheck().equals("no")) {
				 System.out.println("아이디 삽입");
				 sql = "insert into usecoupon (Id) values (?)";
				 template.update(sql,new Object[] {cnumber});
				 System.out.println("쿠폰 사용");
				 sql = "update coupon set usecheck = 'yes' where Id = ?";
				 template.update(sql,new Object[] {cnumber});
				 
				 couponresult = coupon.getType();
			 }
			 //else 
			 //	 couponresult = 10;
			 */
			  Session session = getSession();
			  int couponresult = 10;
			  Coupon coupon = null;
			  Query<Coupon> query = session.createQuery("from Coupon where id = :id",Coupon.class);
			  query.setParameter("id",cnumber);
			  List<Coupon> coupons = query.getResultList();
			  if(coupons.size() == 0) {
				  couponresult = 10;
			  } else {
				  coupon = coupons.get(0);
				  couponresult = coupon.getType();
			  }
			  /*
			  if(coupon != null && coupon.getUsecheck().equals("no")) {
				  Usecoupon usecoupon = new Usecoupon();
				  usecoupon.setId(cnumber);
				  session.saveOrUpdate(usecoupon);
				  query = session.createQuery("update Coupon set usecheck = :usecheck where id = :id");
				  query.setParameter("usecheck","yes");
				  query.setParameter("id",cnumber);
				  query.executeUpdate();
				  couponresult = coupon.getType();
			  }*/
			  //couponresult = coupon.getType();
		//}catch(Exception e) {
			  //e.printStackTrace();
			  //System.out.println("롤백");
			  //status.setRollbackOnly();
		 //}
	    //}
	 //});
	 	return couponresult;
	}
	 
	public Integer receivecoupon(String id) {
		/*transactionTemplate1.execute(new TransactionCallbackWithoutResult() {
			@Override
			protected void doInTransactionWithoutResult(TransactionStatus status) {
				try {
					String sql = "select * from coupon where user = ? and receive = 'no'";
					List<Coupon> coupons = new ArrayList<Coupon>();
					try {
						coupons = template.query(sql,new Object[] {id},new RowMapper<Coupon>() {
							public Coupon mapRow(ResultSet rs,int rowNum) throws SQLException {
								Coupon coupon = new Coupon();
								coupon.setId(rs.getString("Id"));
								coupon.setReceive(rs.getString("receive"));
					
								return coupon;
							}
						});
					} catch(Exception e) {
			
					}
		
					if(coupons.size() > 0) {
						sql = "update coupon set receive = ? where user = ?";
						template.update(sql,new Object[] {"yes",id});
						receivecoupon = 1;
					}
					else {
						receivecoupon = 0;
					}
				} catch(Exception e) {
					status.setRollbackOnly();
				}
			}
		});
		*/
		Session session = getSession();
		int receivecoupon = 1;
		Query<Coupon> query = session.createQuery("from Coupon where user = :user and receive = :receive");
		query.setParameter("user",id);
		query.setParameter("receive","no");
		List<Coupon> couponlist = query.getResultList();
		if(couponlist.size() > 0) {
			query = session.createQuery("update Coupon set receive = :receive where user = :user");
			query.setParameter("receive","yes");
			query.setParameter("user",id);
			query.executeUpdate();
			receivecoupon = 1; //쿠폰 모두 받음
		} else {
			receivecoupon = 0;	//받을수 있는 쿠폰 없음
		}
		return receivecoupon;
	}

	public List<Coupon> getcoupons(String id) {
		/*
		final String sql = "select * from coupon where Id = ?";
		List<Coupon> coupons;
		coupons = template.query(sql,new Object[] {id},new RowMapper<Coupon>() {
			public Coupon mapRow(ResultSet rs,int rowNum) throws SQLException {
				Coupon coupon = new Coupon();
				coupon.setId(rs.getString("Id"));
				coupon.setMaketime(rs.getTimestamp("maketime"));
				coupon.setType(rs.getInt("type"));
				coupon.setUsecheck(rs.getString("usecheck"));
				
				return coupon;
			}
		});
		return coupons;
		*/
		Session session = getSession();
		Query<Coupon> query = session.createQuery("from Coupon where id = :id");
		query.setParameter("id",id);
		List<Coupon> couponlist = query.getResultList();
		return couponlist;
	}

	public Coupon getcoupon(String id) {
		Session session = getSession();
		Query query = session.createQuery("from Coupon where id = :id");
		query.setParameter("id",id);
		Coupon coupon = (Coupon)query.getSingleResult();
		return coupon;
	}
	
	
	
	public int getNumberCoupons(String id) {
		/*
		final String sql = "select * from coupon where user = ?";
		List<Coupon> coupons = null;
		coupons = template.query(sql,new Object[] {id},new RowMapper<Coupon>() {
			public Coupon mapRow(ResultSet rs,int rowNum) throws SQLException
			{
				Coupon coupon = new Coupon();
				coupon.setId(rs.getString("Id"));
				
				return coupon;
			}
		});
		return coupons.size();
		*/
		Session session = getSession();
		Query<Coupon> query = session.createQuery("from Coupon where user = :user and receive = :receive",Coupon.class);
		query.setParameter("user",id);
		query.setParameter("receive","yes");
		List<Coupon> couponlist = query.getResultList();
		return couponlist.size();
	}

	public List<Coupon> getCurPageCoupons(int curPageNum, String id) 
	{
		/*
		String sql = "select R1.* FROM( SELECT * FROM coupon where user = ? and receive = 'yes' order by Id asc) R1 LIMIT ?, ?";
		List<Coupon> coupons = null;
		coupons = template.query(sql,new Object[] {id,6 * (curPageNum - 1),6},new RowMapper<Coupon>() {
			public Coupon mapRow(ResultSet rs,int rowNum) throws SQLException{
				Coupon coupon = new Coupon();
				coupon.setId(rs.getString("Id"));
				coupon.setType(rs.getInt("type"));
				coupon.setUsecheck(rs.getString("usecheck"));
				
				return coupon;
			}
		});
		return coupons;
		*/
		Session session = getSession();//order by id asc
		Query<Coupon> query = session.createQuery("from Coupon where user = :user and receive = :receive order by maketime desc",Coupon.class);
		query.setParameter("user",id);
		query.setParameter("receive","yes");
		query.setFirstResult(6 * (curPageNum - 1)).setMaxResults(6);
		List<Coupon> couponlist = query.getResultList();
		return couponlist;
	}

	public void updateusecouponservice(String yes,String cnumber) {
		/*
		transactionTemplate1.execute(new TransactionCallbackWithoutResult() {
		 @Override
		 protected void doInTransactionWithoutResult(TransactionStatus status) {
			try {
			 String sql = "select * from coupon where Id = ?";
			 Coupon coupon;
			 coupon = template.queryForObject(sql,new Object[] {cnumber},new RowMapper<Coupon>() {
				public Coupon mapRow(ResultSet rs,int rowNum) throws SQLException {
					Coupon coupon = new Coupon();
					coupon.setUsecheck(rs.getString("usecheck"));
					
					return coupon;
				}
			 });
			 
			 	if(coupon.getUsecheck().equals("no")) {	
			 		System.out.println("쿠폰 사용");
			 		sql = "update coupon set usecheck = ? where Id = ?";
			 		template.update(sql,new Object[] {yes,cnumber});
			 	}
			}catch(Exception e) {
				System.out.println("롤백");
				status.setRollbackOnly();
			}
		 }
	   });
	   */
		Session session = getSession();
		Query query = session.createQuery("from Coupon where id = :id");
		query.setParameter("id",cnumber);
		Coupon coupon = (Coupon)query.getSingleResult();
		if(coupon.getUsecheck().equals("no")) {
			System.out.println("쿠폰 사용");
			query = session.createQuery("update Coupon set usecheck = :usecheck where id = :id");
			query.setParameter("usecheck",yes);
			query.setParameter("id",cnumber);
			query.executeUpdate();
		}
	}

	public void updatediscountpercent(String couponId,String merchant_id) {
		/*
		final String sql = "update ordertable set couponId = ? where merchant_id = ?";
		template.update(sql,new Object[] {couponId,merchant_id});
		*/
		Session session = getSession();
		Query query = session.createQuery("update Order set couponid = :couponid where merchant_id = :merchant_id");
		query.setParameter("couponid",couponId);
		query.setParameter("merchant_id",merchant_id);
		query.executeUpdate();
	}

	public User getJeongbo(String id) {
		 String sql = "select * from user where Id = ?";
		 User user = null;
		 user = template.queryForObject(sql,new Object[] {id},new RowMapper<User>() {
			public User mapRow(ResultSet rs,int rowNum) throws SQLException {
				User user = new User();
				user.setAddress(rs.getString("address"));
				user.setEmail(rs.getString("email"));
				user.setName(rs.getString("name"));
				user.setPhoneNumber(rs.getString("phonenumber"));
				
				return user;
			}
		 });
		return user;
	}

	public void deleteall(String id) {
		/*
		String sql = "delete from shoppingbasket where user_id = ?";
		template.update(sql,new Object[]{id});
		*/
		Session session = getSession();
		Query query = session.createQuery("delete from Shoppingbasket where user_id = :user_id");
		query.setParameter("user_id",id);
		query.executeUpdate();
	}

	public List<Reply> commentlist(String gId) 
	{
		/*
		String sql = "select * from reply where gId = ? order by rId";
		List<Reply> replies;
		replies = template.query(sql,new Object[] {gId},new RowMapper<Reply>() {
			@Override
			public Reply mapRow(ResultSet rs, int rowNum) throws SQLException {
				Reply reply = new Reply();
				reply.setGid(rs.getString("gId"));
				reply.setContent(rs.getString("content"));
				reply.setUser_id(rs.getString("user_id"));
				reply.setRid(rs.getInt("rId"));
				return reply;
			}
		});
		return replies;
		*/
		Session session = getSession();
		Query<Reply> query = session.createQuery("from reply where gid = :gid order by rid",Reply.class);
		query.setParameter("gid",gId);
		List<Reply> replylist = query.getResultList();
		return replylist;
	}

	public boolean addComment(String gId, String user_id, String reply) {
		/*
		String sql = "insert into reply (gId,user_id,content) values (?,?,?)";
		template.update(sql,new Object[] {gId,user_id,reply});
		return true;
		*/
		logger.info("addcomment 메소드 실행");
		Session session = getSession();
		Reply Newreply = new Reply();
		Newreply.setGid(gId);
		Newreply.setUser_id(user_id);
		Newreply.setContent(reply);
		Newreply.setReviewpoint(0);
		Query selectgid = session.createQuery("from Goods where name = :name");
		selectgid.setParameter("name",gId);
		Goods book = (Goods)selectgid.getSingleResult();
		Newreply.setGoodsid(book);
		session.saveOrUpdate(Newreply);
		return true;
	}
	
	public boolean addreview(Reply reply) {
		logger.info("addreview 메소드 실행");
		Session session = getSession();
		Query selectbook = session.createQuery("from Goods where name = :name");
		logger.info("name : {}",reply.getGid());
		selectbook.setParameter("name",reply.getGid());
		Goods book = (Goods)selectbook.getSingleResult();
		reply.setGoodsid(book);
		session.saveOrUpdate(reply);
		return true;
	}

	public void contentreplymodify(String gId, String rId, String content) 
	{
		/*
		String sql = "update reply set content = ? where gId = ? and rId = ?";
		template.update(sql,new Object[] {content,gId,Integer.valueOf(rId)});
		*/
		Session session = getSession();
		Query query = session.createQuery("update Reply set content = :content where gid = :gid and rid = :rid");
		query.setParameter("content",content);
		query.setParameter("gid",gId);
		query.setParameter("rid",Integer.valueOf(rId));
		query.executeUpdate();
	}

	public void contentreplydelete(String gId, String rId) 
	{
		/*
		String sql = "delete from reply where gId = ? and rId = ?";
		template.update(sql,new Object[] {gId,Integer.valueOf(rId)});
		*/
		Session session = getSession();
		Query query = session.createQuery("delete from Reply where gid = :gid and rid = :rid");
		query.setParameter("gid",gId);
		query.setParameter("rid",Integer.valueOf(rId));
		query.executeUpdate();
	}

	public int getNumberReply(String gId) 
	{
		/*
		final String sql = "select * from reply where gId = ?";
		List<Reply> replies = null;
		replies = template.query(sql,new Object[] {gId},new RowMapper<Reply>() {
			public Reply mapRow(ResultSet rs,int rowNum) throws SQLException
			{
				Reply reply = new Reply();
				reply.setRid(rs.getInt("rId"));
				return reply;
			}
		});
		return replies.size();
		*/
		Session session = getSession();
		Query<Reply> query = session.createQuery("from Reply where gid = :gid",Reply.class);
		query.setParameter("gid",gId);
		List<Reply> replylist = query.getResultList();
		return replylist.size();
	}

	public List<Reply> getCurPageReplies(int curPageNum, String gId) {  //gId는 책의 이름
		/*String sql = "select R1.* FROM( SELECT * FROM reply where gId = ? order by rId desc) R1 LIMIT ?, ?";
		List<Reply> replies = null;
		replies = template.query(sql,new Object[] {gId,6 * (curPageNum - 1),6},new RowMapper<Reply>() {
			public Reply mapRow(ResultSet rs,int rowNum) throws SQLException{
				Reply reply = new Reply();
				reply.setContent(rs.getString("content"));
				reply.setUser_id(rs.getString("user_id"));
				reply.setRid(rs.getInt("rId"));
				reply.setGid(rs.getString("gId"));
				
				return reply;
			}
		});
		return replies;
		*/
		Session session = getSession();
		Query<Reply> query = session.createQuery("from Reply where gid = :gid order by rid desc",Reply.class);
		query.setFirstResult(6 * (curPageNum - 1)).setMaxResults(6);
		query.setParameter("gid",gId);
		List<Reply> replylist = query.getResultList(); 
        return replylist;
	}

	public boolean mobilecheck(String merchant_uid) {
		/*
		String sql = "select * from ordergoods where merchant_id = ?";
		Order order = null;
		try {
		order = template.queryForObject(sql,new Object[] {merchant_uid},new RowMapper<Order>() {
			public Order mapRow(ResultSet rs,int rowNum) throws SQLException {
				Order order = new Order();
				order.setMerchant_id(rs.getString("merchant_id"));
				
				return order;
			}
		});
			return true;
		} catch(EmptyResultDataAccessException e) {
			return false;
		}
		*/
		Session session = getSession();
		Query<Ordergoods> query = session.createQuery("from Ordergoods where merchant_id = :merchant_id");
		query.setParameter("merchant_id",merchant_uid);
		List<Ordergoods> ordergoodslist = query.getResultList();
		if(ordergoodslist.size() > 0) {
			return true;
		} else {
			return false;
		}
	}

	public void updatestatususecoupon(String couponid,String merchant_id) {
		Session session = getSession();
		Usecoupon usecoupon = new Usecoupon();
		usecoupon.setId(couponid);
		session.saveOrUpdate(usecoupon);
		Query query = session.createQuery("update Coupon set usecheck = :usecheck where id = :id");
		query.setParameter("usecheck","yes");
		query.setParameter("id",couponid);
		query.executeUpdate();
		Query query2 = session.createQuery("update Order set couponid = :couponid where merchant_id = :merchant_id");
		query2.setParameter("couponid",couponid);
		query2.setParameter("merchant_id",merchant_id);
		query2.executeUpdate();
	}

	public int usedcouponcheckmethod(String couponid) {
		Session session = getSession();
		Query<Usecoupon> query = session.createQuery("from Usecoupon where id = :id");
		query.setParameter("id",couponid);
		List<Usecoupon> usecoupon = query.getResultList();
		if(usecoupon.size() > 0)
			return 1;
		else
			return 0;
	}

	public int bookrecommend(Bookrecommend recommend) {
		Session session = getSession();
		session.save(recommend);
		Query query = session.createQuery("update Goods set recommend = recommend + 1 where id = :id");
		query.setParameter("id",recommend.getBookid());
		int rowAffected = query.executeUpdate();
		if(rowAffected > 0) {
			return 0;
		} else {
			return 1;
		}
	}

	public int bookrecommendcheck(String userid, int bookid) {
		Session session = getSession();
		Query<Bookrecommend> query = session.createQuery("from Bookrecommend where userid = :userid and bookid = :bookid");
		query.setParameter("userid",userid);
		query.setParameter("bookid",bookid);
		List<Bookrecommend> recommendcheck = query.getResultList();
		if(recommendcheck.size() > 0) {
			return 1;
		} else {
			return 0;
		}
	}

	public int getcouponscountbyuserId(String id) {
		Session session = getSession();
		Query query = session.createQuery("from Coupon where user = :user and receive = :receive");
		query.setParameter("user",id);
		query.setParameter("receive","no");
		List<Coupon> coupon = query.getResultList();
		if(coupon.size() == 0) {
			return 0;
		} else {
			return coupon.size();
		}
	}

	public List<Goods> getmonthbooklist(int curPageNum) {
		Session session = getSession();
		Query<Goods> query = session.createQuery("from Goods order by purchase desc");
		query.setFirstResult(5 * (curPageNum - 1)).setMaxResults(5);
		List<Goods> goodslist = query.getResultList();
		return goodslist;
	}

	public void setmonthbooklist(List<String> selectedbooklist) {
		Session session = getSession();
		for(int i=0;i<selectedbooklist.size();i++) {
			Goods goods = session.get(Goods.class,Integer.valueOf(selectedbooklist.get(i)));
			Monthbook monthbook = new Monthbook();
			monthbook.setName(goods.getName());
			monthbook.setPrice(goods.getPrice());
			monthbook.setGoodsprofile(goods.getGoodsprofile());
			monthbook.setRecommend(goods.getRecommend());
			monthbook.setItemid(goods.getId());
			monthbook.setBigclass(goods.getBigclass());
			monthbook.setSubclass(goods.getSubclass());
			session.save(monthbook);
		}
	}

	public List<Monthbook> getmonthbooklistInmonthbooktable() {
		Session session = getSession();
		Query<Monthbook> query = session.createQuery("from Monthbook",Monthbook.class);
		return query.getResultList();
	}

	public int getCountGoods() {
		Session session = getSession();
		Query<Goods> query = session.createQuery("from Goods",Goods.class);
		return query.getResultList().size();
	}

	public void downmonthbooklist() {
		Session session = getSession();
		Query query = session.createQuery("delete from Monthbook where id > 0");
		query.executeUpdate();
	}

	public Goods findbook(String name) {
		Session session = getSession();
		Query<Goods> query = session.createQuery("from Goods where name = :name",Goods.class);
		query.setParameter("name",name);
		Goods goods = (Goods)(query.getSingleResult());
		return goods;
	}

	public void settodaybookselect(int bookid) {
		Session session = getSession();
		Goods goods = session.get(Goods.class,bookid);
		Todaybook todaybook = new Todaybook();
		todaybook.setName(goods.getName());
		todaybook.setSummary(goods.getSummary());
		todaybook.setGoodsprofile(goods.getGoodsprofile());
		todaybook.setRecommend(goods.getRecommend());
		session.save(todaybook);
	}

	public Todaybook gettodaybook() {
		Session session = getSession();
		Query query = session.createQuery("from Todaybook order by id desc");
		query.setMaxResults(1);
		return (Todaybook)(query.getSingleResult());
	}

	public void purchasecancel(HashMap<String, Object> map) { //pusrchase 다시 복구 시키기
		Session session = getSession();
		String merchant_id = (String)(map.get("merchant_uid"));
		Query<Ordergoods> query = session.createQuery("from Ordergoods where merchant_id = :merchant_id");
		query.setParameter("merchant_id",merchant_id);
		List<Ordergoods> ordergoodslist = query.getResultList();
		for(int i=0;i<ordergoodslist.size();i++) {
			Query query2 = session.createQuery("update Goods set purchase = purchase - " + 
					(ordergoodslist.get(i).getQty()) + 
					" where name = :name");
			query2.setParameter("name",ordergoodslist.get(i).getName());
			query2.executeUpdate();
		}
	}

	public List<Reply> getAllReply(String bookname) {
		Session session = getSession();
		Query<Reply> query = session.createQuery("from Reply where gId = :gId");
		query.setParameter("gId",bookname);
		return query.getResultList();
	}

	public void addreviewreply(ReviewReply userreview,int rid) {
		Session session = getSession();
		Query<Reply> query = session.createQuery("from Reply where rid = :rid");  //수정되야할 코드 부분
		query.setParameter("rid",rid);  //코드 수정
		Reply reply = query.getSingleResult();  //one to many
		userreview.setRid(reply);   							//코드 수정 부분 -> 원래는 없어야 할 부분
		//userreview.setReviewid(reply);  //many to one
		reply.getReviewreplylist().add(userreview);	//one to many
		for(int i=0;i<reply.getReviewreplylist().size();i++)
			logger.info("reviewreplyid : {}",reply.getReviewreplylist().get(i).getReviewreplyid());
		session.saveOrUpdate(userreview);
	}

	public List<ReviewReply> getreviewreply(String gId) {
		Session session = getSession();
		Query<ReviewReply> query = session.createQuery("from ReviewReply where bookname = :bookname order by reviewreplyid desc");
		query.setParameter("bookname",gId);
		List<ReviewReply> reviewreplylist = query.getResultList();
		return reviewreplylist;
	}

	public void reviewmodify(String content, int reviewid) {
		Session session = getSession();
		Query query = session.createQuery("update Reply set content = :content where rid = :reviewreplyid");
		query.setParameter("content",content);
		query.setParameter("reviewreplyid",reviewid);
		query.executeUpdate();
	}

	public void reviedelete(int reviewid) {
		Session session = getSession();
		Query<Reply> query = session.createQuery("from Reply where rid = :rid");
		query.setParameter("rid",reviewid);
		Reply reply = query.getSingleResult();
		session.delete(reply);
		//Query<Recommend> query2 = session.createQuery("from Recommend where reviewid = :reviewid");  //수정된 코드
		//query2.setParameter("reviewid",reviewid);
		//Recommend recommend = query2.getSingleResult();
		//session.delete(recommend);
		
		
		
		
		/*
		Query query = session.createQuery("delete from Reply where rid = :rid");
		query.setParameter("rid",reviewid);
		query.executeUpdate();
		//왜 이건 안되는거지;
		*/ 
	}
 
	public void reviewreplydelete(int reviewreplyid) {
		Session session = getSession();
		Query<ReviewReply> query = session.createQuery("from ReviewReply where reviewreplyid = :reviewreplyid");
		query.setParameter("reviewreplyid",reviewreplyid);
		ReviewReply reviewreply = query.getSingleResult();
		session.delete(reviewreply);
		
		//Query<Recommend> query2 = session.createQuery("from Recommend where reviewreplyid = :reviewreplyid");  //수정된 코드
		//query2.setParameter("reviewreplyid",reviewreplyid);
		//Recommend recommend = query2.getSingleResult();
		//session.delete(recommend);
	}

	public void reviewrecommend(int reviewid,String userid) {
		/*
		Session session = getSession();
		Recommend recommend = new Recommend();
		recommend.setReviewid(reviewid);
		recommend.setUser_id(userid);
		session.save(recommend);
		Query query = session.createQuery("update Reply set good = good + 1 where rid = :rid");
		query.setParameter("rid",reviewid);
		query.executeUpdate();
		*/
		Session session = getSession();
		Query<Reply> selectreply = session.createQuery("from Reply where rid = :rid");
		selectreply.setParameter("rid",reviewid);
		Reply reply = selectreply.getSingleResult();
		ReviewRecommend recommend = new ReviewRecommend();
		recommend.setReviewid(reply);
		recommend.setUser_id(userid);
		reply.setReviewrecommend(recommend);
		session.save(recommend);
		logger.info("reviewrecommend 실행 완료");
		Query query = session.createQuery("update Reply set good = good + 1 where rid = :rid");
		query.setParameter("rid",reviewid);
		query.executeUpdate();
	}

	public void reviewreplyrecommend(int reviewreplyid,String userid){
		/*
		Session session = getSession();
		Recommend recommend = new Recommend();
		recommend.setReviewreplyid(reviewreplyid);
		recommend.setUser_id(userid);
		session.save(recommend);
		Query query = session.createQuery("update ReviewReply set good = good + 1 where reviewreplyid = :reviewreplyid");
		query.setParameter("reviewreplyid",reviewreplyid);
		query.executeUpdate();
		*/
		Session session = getSession();
		Query<ReviewReply> selectreviewreply = session.createQuery("from ReviewReply where reviewreplyid = :reviewreplyid");
		selectreviewreply.setParameter("reviewreplyid",reviewreplyid);
		ReviewReply reply = selectreviewreply.getSingleResult();
		ReviewReplyRecommend recommend = new ReviewReplyRecommend();
		recommend.setReviewreplyid(reply);
		recommend.setUser_id(userid);
		reply.setReviewreplyrecommend(recommend);
		session.save(recommend);
		Query query = session.createQuery("update ReviewReply set good = good + 1 where reviewreplyid = :reviewreplyid");
		query.setParameter("reviewreplyid",reviewreplyid);
		query.executeUpdate();
	}

	public boolean reviewrecommendcheck(int reviewid,String userid) {
		/*
		Session session = getSession();
		Query<Recommend> query = session.createQuery("from Recommend where reviewid = :reviewid");
		query.setParameter("reviewid",reviewid);
		List<Recommend> recommendlist = query.getResultList();
		boolean recommendflag = true;
		for(int i=0;i < recommendlist.size();i++) {
			if(recommendlist.get(i).getUser_id().equals(userid)) {
				recommendflag = false;  //이미 좋아요 버튼을 눌렀음
				break;
			}
		}
		return recommendflag;
		*/
		
		Session session = getSession();
		Query<ReviewRecommend> query = session.createQuery("from ReviewRecommend where user_id = :user_id");
		query.setParameter("user_id",userid);
		List<ReviewRecommend> reviewrecommendlist = query.getResultList();
		boolean reviewrecommendflag = true;
		for(int i=0;i < reviewrecommendlist.size();i++) {
			if(reviewrecommendlist.get(i).getReviewid().getRid() == reviewid) {
				reviewrecommendflag = false;  //이미 좋아요 버튼을 눌렀음
				break;
			}
		}
		return reviewrecommendflag;
	}

	public boolean reviewreplyrecommendcheck(int reviewreplyid, String userid) {
		/*
		Session session = getSession();
		Query<Recommend> query = session.createQuery("from Recommend where reviewreplyid = :reviewreplyid");
		query.setParameter("reviewreplyid",reviewreplyid);
		List<Recommend> recommendlist = query.getResultList();
		boolean recommendflag = true;
		for(int i=0;i < recommendlist.size();i++) {
			if(recommendlist.get(i).getUser_id().equals(userid)) {
				recommendflag = false;  //이미 좋아요 버튼을 눌렀음
				break;
			}
		}
		return recommendflag;
		*/
		Session session = getSession();
		Query<ReviewReplyRecommend> query = session.createQuery("from ReviewReplyRecommend where user_id = :user_id");
		query.setParameter("user_id",userid);
		List<ReviewReplyRecommend> reviewreplyrecommendlist = query.getResultList();
		boolean reviewreplyrecommendflag = true;
		for(int i=0;i < reviewreplyrecommendlist.size();i++) {
			if(reviewreplyrecommendlist.get(i).getReviewreplyid().getReviewreplyid() == reviewreplyid) {
				reviewreplyrecommendflag = false;  //이미 좋아요 버튼을 눌렀음
				break;
			}
		}
		return reviewreplyrecommendflag;
	}


	/*
	public Shoes getshoesinfo(String name) 
	{
		String sql = "select * from shoes where name = ?";
		Shoes shoe = template.queryForObject(sql,new Object[] {name},new RowMapper<Shoes>() {
			@Override
			public Shoes mapRow(ResultSet rs, int rowNum) throws SQLException {
				Shoes shoe = new Shoes();
				shoe.setId(rs.getInt("id"));
				shoe.setName(rs.getString("name"));
				shoe.setManufacturer(rs.getString("manufacturer"));
				shoe.setSex(rs.getString("sex"));
				shoe.set_170(rs.getInt("170"));
				shoe.set_180(rs.getInt("180"));
				shoe.set_190(rs.getInt("190"));
				shoe.set_200(rs.getInt("200"));
				shoe.set_210(rs.getInt("210"));
				shoe.set_220(rs.getInt("220"));
				shoe.set_230(rs.getInt("230"));
				shoe.set_240(rs.getInt("240"));
				shoe.set_250(rs.getInt("250"));
				shoe.set_260(rs.getInt("260"));
				shoe.set_270(rs.getInt("270"));
				shoe.set_280(rs.getInt("280"));
				shoe.set_290(rs.getInt("290"));
				shoe.set_300(rs.getInt("300"));
				shoe.set_310(rs.getInt("310"));
				shoe.set_320(rs.getInt("320"));
				shoe.set_330(rs.getInt("330"));
				
				return shoe;
			}
		});
		return shoe;
	}
	*/
}
