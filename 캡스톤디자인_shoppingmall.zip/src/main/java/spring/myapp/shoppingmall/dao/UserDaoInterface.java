package spring.myapp.shoppingmall.dao;

import spring.myapp.shoppingmall.dto.User;

public interface UserDaoInterface {
	//public void join(String Id,String Password,String Name,String Address,String Sex,int Age,String PhoneNumber,String email);
	public void join(User user);
}
