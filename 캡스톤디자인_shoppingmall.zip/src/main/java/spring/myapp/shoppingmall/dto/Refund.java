package spring.myapp.shoppingmall.dto;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@NoArgsConstructor
@Entity
@Table(name = "requestrefund")
public class Refund 
{
	@Id
	private String merchant_id;
	private int amount;
	private String refundholder;
	private String refundbank;
	private String refundaccount;
	private String status;
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "orderid")
	private Order orderid;
}
