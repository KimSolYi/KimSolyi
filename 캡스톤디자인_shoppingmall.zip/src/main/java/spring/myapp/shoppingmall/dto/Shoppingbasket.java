package spring.myapp.shoppingmall.dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
@Entity
@Table(name = "shoppingbasket")
public class Shoppingbasket 
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int pnum;
	private int goods_id;
	private String user_id;
	private int price;
	private String thumbnail;
	private String name;
	private int qty;
}