package spring.myapp.shoppingmall.security;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import spring.myapp.shoppingmall.dto.User;

public class LoginSocialAuthentication {
	public static void Authentication(User userinfo,HttpSession session,HttpServletRequest request){
		Authentication authentication  = new UsernamePasswordAuthenticationToken(userinfo,userinfo.getPassword(),AuthorityUtils.createAuthorityList(userinfo.getAuthorities()));
		SecurityContext securityContext = SecurityContextHolder.getContext();
		securityContext.setAuthentication(authentication);
		session = request.getSession(true);
		session.setAttribute("SPRING_SECURITY_CONTEXT",securityContext);   // ���ǿ� spring security context ����
	}
}
