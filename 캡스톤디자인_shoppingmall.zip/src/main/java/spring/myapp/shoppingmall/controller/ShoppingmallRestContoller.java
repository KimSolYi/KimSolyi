package spring.myapp.shoppingmall.controller;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import spring.myapp.shoppingmall.dto.Bookrecommend;
import spring.myapp.shoppingmall.dto.Reply;
import spring.myapp.shoppingmall.dto.ReviewReply;
import spring.myapp.shoppingmall.dto.Shoppingbasket;
import spring.myapp.shoppingmall.dto.User;
import spring.myapp.shoppingmall.restcontrollerexception.UserNotFindExceptionHandler;
import spring.myapp.shoppingmall.service.AdminServiceImpl;
import spring.myapp.shoppingmall.service.AwsServiceImpl;
import spring.myapp.shoppingmall.service.CouponServiceImpl;
import spring.myapp.shoppingmall.service.OrderServiceImpl;
import spring.myapp.shoppingmall.service.ProductServiceImpl;
import spring.myapp.shoppingmall.service.ReplyServiceImpl;
import spring.myapp.shoppingmall.service.RequestRefund;
import spring.myapp.shoppingmall.service.ShoppingBasketImpl;
import spring.myapp.shoppingmall.service.UserServiceImpl;

@RestController
public class ShoppingmallRestContoller {
	private static final Logger logger = LoggerFactory.getLogger(ShoppingmallRestContoller.class);
	@Autowired
	private ShoppingBasketImpl shoppingbasketimpl;
	
	@Autowired
	private UserServiceImpl userserviceimpl;
	
	@Autowired
	private ProductServiceImpl productserviceimpl; 
	
	@Autowired
	private OrderServiceImpl orderserviceimpl;
	
	@Autowired
	private RequestRefund requestrefund;
	
	@Autowired
	private AdminServiceImpl adminserviceimpl;
	
	@Autowired
	private AwsServiceImpl awsserviceimpl;
	
	@Autowired
	private CouponServiceImpl couponserviceimpl;
	
	@Autowired
	private ReplyServiceImpl replyserviceimpl;
	
	@PostMapping(value = "/cart")  //��ٱ��Ͽ� ���
	public void cart(Shoppingbasket cart){
		logger.info("��ٱ��� - ��ǰ ���̵� : {},���̵� : {}",cart.getGoods_id(),cart.getUser_id());
		logger.info("��ٱ��� - å�̸� : {},���� : {}",cart.getName(),cart.getQty());
		logger.info("��ٱ��� - å�� ���� ���� : {}",cart.getPrice());
		shoppingbasketimpl.setshoppingbasket(cart.getQty(),cart.getGoods_id(),cart.getPrice(),cart.getUser_id(),cart.getName());
	}
	
	@RequestMapping(value = "/shoppingbasket",method = {RequestMethod.POST,RequestMethod.GET}) //�ֹ��ϱ⿡�� ��ٱ��Ͽ� ���� ���� �ֹ��ϱ� â���� �̵�
	public ResponseEntity<String> shoppingbasket(@RequestBody HashMap<String,Object> map,HttpSession session){
		   int qty;
		   String TypeCheck = map.get("qty").getClass().getName();
		   if(TypeCheck.equals("java.lang.String")){
			   qty = Integer.valueOf((String)map.get("qty"));
		   } else {
			   qty = ((Double)map.get("qty")).intValue();
		   }
		   String UserId = (String)(session.getAttribute("Userid"));
		   int gid = Integer.valueOf((String)map.get("goods_id"));
		   int price = Integer.valueOf((String)map.get("price"));
		   String name = (String)map.get("name");
		   logger.info("�ֹ��ϱ� - ��ǰ ���̵� : {},���̵� : {}",gid,UserId);
		   logger.info("�ֹ��ϱ� - å�̸� : {},���� : {}",name,qty);
		   logger.info("�ֹ��ϱ� - å�� ���� ���� : {}",price);
		   shoppingbasketimpl.setshoppingbasket(qty, gid,price,UserId,name);  //��ٱ��� ����Ʈ�� �ֱ�
		   return new ResponseEntity<String>("yes",HttpStatus.CREATED);
	}
	
	@PostMapping("/cartspace")
	public ResponseEntity<Integer> cartspace(@RequestBody HashMap<String,Object> map) {  //�ֹ��ϱ⸦ ������,���� ��ٱ��� �ȿ� 10���� �Ѿ��,�ֹ��ϱ� â���� �� �Ѿ���� Ȯ��
		String Id = (String)(map.get("Id"));
		int cartspace = shoppingbasketimpl.checkcartspace(Id);  //������ ��ٱ��Ͽ� �󸶳� �����ִ��� Ȯ��
		return new ResponseEntity<Integer>(cartspace,HttpStatus.CREATED);
	}
	
	@PostMapping("/jeongbo")
	public ResponseEntity<JSONObject> jeongbo(@RequestBody HashMap<String,Object> map){  //������ ������ DB���� Ȯ���ϱ�(�̸�,�ּ�,�ڵ��� ��ȣ,�̸���)
		String Id = (String)(map.get("Id")); //(String)(map.get("Id"));
		logger.info("Id : {}",Id);
		JSONObject data = new JSONObject();
		User user = userserviceimpl.finduserbyid(Id);  //������ ����
		if(user == null) {
			throw new UserNotFindExceptionHandler(Id);
		}
		data.put("name",user.getName());
		data.put("address",user.getAddress());
		data.put("phone",user.getPhoneNumber());
		data.put("email",user.getEmail());
		return new ResponseEntity<JSONObject>(data,HttpStatus.OK);
	}
	
	@GetMapping("/remaincheck")
	public ResponseEntity<Integer> remaincheck(@RequestParam String[] newname,@RequestParam Integer[] newqty){
		int check;
		return new ResponseEntity<Integer>((Integer)(productserviceimpl.remaincheck(newname,newqty)),HttpStatus.OK);
	}

	@PostMapping("/completeToken")//������Ʈ �������� ���� ������ �������� �� MySQL ���� ������ ����ȭ,HttpServletRequest request,HttpServletResponse response ����
	public ResponseEntity<JSONObject> completeToken(@RequestBody HashMap<String,Object> map,HttpSession session) throws Exception{
		logger.info("����ڰ� �Է��� �ֹ� ���� : {}",map);
		JSONObject json = new JSONObject();
		String imp_key = URLEncoder.encode("2645427372556228", "UTF-8");
		String imp_secret =	URLEncoder.encode("75USkRpzuQ8T8WeQcJrO1GFKEERYRDAYIuR2lgCQ6LKfHY5THxIJenuS2mRTZsSHWJKiZm967TlPRrJz", "UTF-8");
		json.put("imp_key",imp_key);
		json.put("imp_secret", imp_secret);
		logger.info("���� ��û JSON ��ü ���� : {}",json);
		logger.info("imp_key : {}",json.get("imp_key"));
		logger.info("imp_secret : {}",json.get("imp_secret"));
		try{
			String token = MallController.getToken(json,"https://api.iamport.kr/users/getToken");
			if(token != null)
				logger.info("iamport api token : {}",token);
			JSONObject getdata = null; //���� ����
			JSONObject paymentjson = requestPaymentinfo(map,token,getdata,"https://api.iamport.kr/payments/" + (String)map.get("imp_uid"),session);
			return new ResponseEntity<JSONObject>(paymentjson,HttpStatus.OK);
		}catch(Exception e) {
			logger.info("token�� �޾ƿ��� ���� ���� �߻��߰ų� �ٸ� ���� �߻�");
			e.printStackTrace();
			JSONObject exceptionjson = new JSONObject();
			exceptionjson.put("check","failed");
			return new ResponseEntity<JSONObject>(exceptionjson,HttpStatus.OK);
		}
	}
	
	private int getamount(String merchant_uid){
		return orderserviceimpl.getpriceBymerchantid(merchant_uid);
	}
	
	@Transactional
	private JSONObject requestPaymentinfo(HashMap<String,Object> map,String token,JSONObject getdata,String requestURL,
			HttpSession session) {
		try{
			String requestString = "";
			//URL url = new URL("https://api.iamport.kr/payments/" + (String)map.get("imp_uid"));
			URL url = new URL(requestURL);
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			connection.setDoOutput(true); 				
			connection.setInstanceFollowRedirects(false);  
			connection.setRequestMethod("GET");
			connection.setRequestProperty("Authorization", token);
			OutputStream os= connection.getOutputStream();
			connection.connect();
			StringBuilder sb = new StringBuilder(); 
			if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
				BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream(), "utf-8"));
				String line = null;  
				while ((line = br.readLine()) != null) {  
					sb.append(line + "\n");  
				}
				br.close();
				requestString = sb.toString();
			}
			os.flush();
			connection.disconnect();
			JSONParser jsonParser = new JSONParser();
			JSONObject jsonObj = (JSONObject) jsonParser.parse(requestString);
			logger.info("���� ������ JSON ��ü ���� : {}",jsonObj);
			if((Long)jsonObj.get("code")  == 0){
				getdata = (JSONObject) jsonObj.get("response");
				if(getdata != null)
					logger.info("�ֹ� ���̵� : {},Payment Info from IamportServer : {}",(String)(map.get("merchant_uid")),getdata);
			}
		}catch(Exception e){
			logger.info("���� ���� - ȸ�� ���̵� : {}",session.getAttribute("Userid"));
			logger.info("requestPaymentinfo �޼ҵ� ����� ���� �߻�");
			e.printStackTrace();  //�̰� �ܼ� â�� ���� ���� ��� ���� �ڵ�� �Ѿư�
			JSONObject exceptionjson = new JSONObject();
			exceptionjson.put("check","failed");
			return exceptionjson;
		}
		logger.info("merchant_uid(������Ʈ �������� �����ص� ���θ� �������� �����ϴ� ����ID : {}",(String)(map.get("merchant_uid")));
		String amount = String.valueOf(getdata.get("amount"));  //Ŭ���̾�Ʈ ������ ������ �ݾ� -> ���� �������κ��� Ȯ��
		String status = String.valueOf(getdata.get("status"));  //���� ������ ����
		logger.info("RestController 185 ----> merchant_uid : {}",(String)(map.get("merchant_uid")));
		int bepaid = getamount((String)(map.get("merchant_uid")));  //DB�� ó�� ����Ǿ� �ִ� �ݾ�
		logger.info("bepaid : {}",bepaid);
		String couponid = (String)(map.get("coupon"));  //����� ���� ���̵�
		ArrayList<String> booknamelistArraylist = (ArrayList<String>)map.get("booknamelist");
		String[] list = booknamelistArraylist.toArray(new String[booknamelistArraylist.size()]);
		logger.info("�ֹ��� å�� �̸� ����Ʈ : {}",booknamelistArraylist);
		ArrayList<Integer> bookqtylistArraylist = (ArrayList<Integer>)map.get("bookqtylist");
		logger.info("�ֹ��� å�� ���� ����Ʈ : {}",bookqtylistArraylist);
		Integer[] bookqtylist = new Integer[bookqtylistArraylist.size()];
		for (int i=0; i < bookqtylist.length; i++)
		    bookqtylist[i] = bookqtylistArraylist.get(i); 
		String merchant_uid = (String)map.get("merchant_uid");
		String imp_uid = (String)map.get("imp_uid");
		String merchant_id = (String)map.get("merchant_id");
		double dprice = (Integer)map.get("price");
		int iprice = (int)(dprice);
		String price = Integer.toString(iprice);
		String paymethod = String.valueOf(getdata.get("pay_method"));
		logger.info("completeToken list[0] -> å�� �̸� ����Ʈ �迭 ù��° ���� : {}",list[0]);
		logger.info("completeToken bookqty[0] -> �ֹ��� å�� ���� �ֹ� ���� : {}",bookqtylist[0]);
		logger.info("���� ������ �ݾ� >= ���� ������ �ݾ� : {} >= {}",Integer.valueOf(amount),bepaid);
		logger.info("���� �ݾ� : {}",amount);
		logger.info("���� : {}",status);
		logger.info("imp_uid - ������Ʈ ���� ������ �����ϴ� �ֹ� ��ȣ : {}",imp_uid);
		logger.info("���� : {}",price);
		logger.info("merchant_id : {}",merchant_id);
		logger.info("merchant_uid - ������Ʈ �������� ����� �� ���������� �ֹ���ȣ: {}",merchant_uid);
		JSONObject resjson = new JSONObject();
		if(Integer.valueOf(amount) >= bepaid){
			logger.info("paymethod : {},buyer_name : {}",String.valueOf(getdata.get("pay_method")),
					String.valueOf(map.get("buyer_name")));
			switch(status) {
			case "ready":	//������� �߱�
				String vbanknum = (String)(map.get("vbanknum"));
				String vbankname = (String)(map.get("vbankname"));
				String vbankdate = (String)(map.get("vbankdate"));
				String vbankholder = (String)(map.get("vbankholder"));
				String buyer_name = String.valueOf(getdata.get("buyer_name"));
				String vbank_code = String.valueOf(getdata.get("vbank_code"));
				logger.info("���� ���̵� - ������� ���� : {}",couponid);
				orderserviceimpl.InsertVbankAndUpdateStatus(merchant_uid,vbanknum,vbankname,vbankdate,vbankholder,buyer_name,
						vbank_code,status,imp_uid,paymethod,merchant_id,list,bookqtylist,price,couponid);
				resjson.put("check","vbankIssued");
				resjson.put("data",getdata);
				resjson.put("vbanknum",orderserviceimpl.getvbankinfo(merchant_uid).getVbanknum());
				logger.info("���� ���� �߱� �Ϸ�");
				return resjson;
			case "paid": //���� �Ϸ�
				logger.info("���� ���̵� - �ֹ� �Ϸ� ���� : {}",couponid);
				orderserviceimpl.updatestatusandorder(status,merchant_uid,imp_uid,paymethod,merchant_id,list,bookqtylist,price,
						null,null,null,couponid);
				resjson.put("check","success");
				resjson.put("data",getdata);
				logger.info("�ֹ� ���� �Ϸ�");
				return resjson;
			default :
				logger.info("���� ���� - requestPaymentMethod");
				resjson.put("check","failed");
				return resjson;
			}
		} else {
			resjson.put("check","failed");
			resjson.put("data",getdata);
			return resjson;
		}
	}
	
	@PostMapping("/InsertMerchantId")
	public ResponseEntity<String> InsertMerchantId(HttpSession session,@RequestBody HashMap<String,Object> map){
		if(orderserviceimpl.orderpaycheck((String)session.getAttribute("Userid"),(String)map.get("price"),
				(String)map.get("coupon")) == 1) {  //�� �����ߴ��� �����ϴ� ����
			return new ResponseEntity<String>("formupdated",HttpStatus.OK);
		}
		String Userid = (String)map.get("id");
		String merchant_id = (String)map.get("merchant_id");
		String phoneNumber = (String)map.get("phoneNumber");
		String address = (String)map.get("address");
		String buyer_name = (String)map.get("buyer_name");
		String memo = (String)map.get("memo");
		String price = (String)map.get("price");
		orderserviceimpl.InsertMerchant(Userid,merchant_id,phoneNumber,address,buyer_name,memo,Integer.valueOf(price)); 
		return new ResponseEntity<String>(merchant_id,HttpStatus.OK);
	}
	
	@PostMapping("/refundadmin")
	public void refundadmin(@RequestBody HashMap<String,Object> map){
		String merchant_id = (String)map.get("merchant_uid");
		String amount = (String)map.get("cancel_request_amount");
		logger.info("������ ȯ�� ��û �ݾ� : {}",amount);
		String holder = null;
		String bank = null;
		String account = null;
		if((String)map.get("refund_holder") != null) {
			holder = (String)map.get("refund_holder");
			bank = (String)map.get("refund_bank");
			account = (String)map.get("refund_account");
		}
		requestrefund.requestrefund(merchant_id,Integer.valueOf(amount), holder, bank, account);
	}
	
	@PostMapping("/cancel")
	@Transactional
	public Map<String,Object> cancel(HttpServletRequest request,HttpServletResponse response,
			@RequestBody HashMap<String,Object> map) throws Exception{
		//logger.info("merchant_uid Ÿ�� üũ : {}",map.get("merchant_uid").getClass().getName());
		//logger.info("cancel_request_amount Ÿ�� üũ : {}",((String)map.get("cancel_request_amount")).getClass().getName());
		//logger.info("refund_holder Ÿ�� üũ : {}",map.get("refund_holder").getClass().getName());
		//logger.info("refund_bank Ÿ�� üũ : {}",map.get("refund_bank").getClass().getName());
		//logger.info("refund_account Ÿ�� üũ : {}",map.get("refund_account").getClass().getName());
		JSONObject json = new JSONObject();
		String imp_key = URLEncoder.encode("2645427372556228", "UTF-8");
		String imp_secret =	URLEncoder.encode("75USkRpzuQ8T8WeQcJrO1GFKEERYRDAYIuR2lgCQ6LKfHY5THxIJenuS2mRTZsSHWJKiZm967TlPRrJz", "UTF-8");
		json.put("imp_key",imp_key);
		json.put("imp_secret", imp_secret);
		logger.info("�������� ȯ�� ��û JSON ���� : {}",json);
		logger.info("imp_key : {}",json.get("imp_key"));
		logger.info("imp_secret : {}",json.get("imp_secret"));
		JSONObject obj = new JSONObject();
		String token = MallController.getToken(json,"https://api.iamport.kr/users/getToken");
		String reason;
		if((String)map.get("reason") != null){
			reason = (String)map.get("reason");
			obj.put("reason",reason);
		}
		int amount = Integer.valueOf(orderserviceimpl.getpriceBymerchantid((String)map.get("merchant_uid")));		//������ ��
		int cancel_request_amount = Integer.valueOf((String)map.get("cancel_request_amount")); //Integer.valueOf((String)map.get("cancel_request_amount"));				
		if((String)map.get("refund_holder") != null){  //������ �Ա� ȯ��
			String imp_uid = orderserviceimpl.getimp_uid((String)(map.get("merchant_uid")));
			obj.put("imp_uid",imp_uid);
			obj.put("merchant_uid",(String)(map.get("merchant_uid")));
			obj.put("cancel_request_amount",(String)map.get("cancel_request_amount"));
			//obj.put("cancel_request_amount",(String)map.get("cancel_request_amount"));
			obj.put("refund_holder",(String)map.get("refund_holder"));
			obj.put("refund_bank",(String)map.get("refund_bank"));
			obj.put("refund_account",(String)map.get("refund_account"));
			logger.info("��û JSON ��ü : {}",obj);
		}
		else{  //������ �Ա� �̿��� �������� ȯ��
			obj.put("imp_uid",orderserviceimpl.getimp_uid((String)(map.get("merchant_uid"))));
			//obj.put("cancel_request_amount",(String)map.get("cancel_request_amount"));
			//obj.put("amount",300.0);
			logger.info("��û JSON ��ü : {}",obj);
		}
		adminserviceimpl.purchasecancel(map);
		JSONObject getcanceldata = null;		//������Ʈ �������� ȯ�� ���� ����
		try{
			String requestString = "";
			URL url = new URL("https://api.iamport.kr/payments/cancel");
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			connection.setDoOutput(true); 				
			connection.setInstanceFollowRedirects(false);  
			connection.setRequestMethod("POST");
			connection.setRequestProperty("Content-Type", "application/json");
			connection.setRequestProperty("Authorization", token);
			OutputStream os= connection.getOutputStream();
			os.write(obj.toString().getBytes());
			connection.connect();
			StringBuilder sb = new StringBuilder(); 
			if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
				BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream(), "utf-8"));
				String line = null;  
				while ((line = br.readLine()) != null) {  
					sb.append(line + "\n");  
				}
				br.close();
				requestString = sb.toString();
			}
			os.flush();
			connection.disconnect();
			try {
			JSONParser jsonParser = new JSONParser();
			JSONObject jsonObj = (JSONObject) jsonParser.parse(requestString);
			logger.info("������Ʈ �������� �޾ƿ� ȯ�� ������ JSON ��ü ���� : {}",jsonObj);
			if((Long)jsonObj.get("code")  == 0){
				getcanceldata = (JSONObject) jsonObj.get("response");
				logger.info("getcanceldata(ȯ�� ����) : {}",getcanceldata );
				//_token = (String)getToken.get("access_token");
			}
		}catch(Exception e) {
			logger.info("ȯ�� ������ �Ľ��ϴ� ���� ���� �߻�");
			e.printStackTrace();
		}
		}catch(Exception e){
			logger.info("ȯ�� ������ ��û�ϴ� ���� ���� �߻�");
			e.printStackTrace();
		}
		return getcanceldata;
	}
	
	@PostMapping("/cancelstatus")
	public void cancelstatus(@RequestBody HashMap<String,Object> map){
		String merchant_id = (String)map.get("merchant_id");
		String cancel = (String)map.get("cancel");
		logger.info("merchant_id : {},cancel : {}",merchant_id,cancel);
		adminserviceimpl.updatestatuscancel(merchant_id, cancel);
	}
	
	@PostMapping("/stop")
	public void stop(@RequestBody HashMap<String,Object> map){
		String merchant_id = (String)map.get("merchant_id");
		orderserviceimpl.deletemerchantid(merchant_id);
	}
	
	@PostMapping("/mobilemaintainsession")
	public void mobilemaintainsession(@RequestParam String Id,HttpSession session){
		if(session.getAttribute("Userid") == null)
			session.setAttribute("Userid",Id);
	}
	
	@PostMapping("/deleteshoppingcart")
	public int deleteshoppingcart(int pnum) {
		shoppingbasketimpl.deleteshoppingbasket(pnum);
		return pnum;
	}
	
	@PostMapping(value = "/upload",produces = "application/text; charset=utf8")
	public String upload(MultipartFile file,@RequestParam(required = false) Integer goods_id,
			@RequestParam(required = false) Integer reviewimgflag) throws Exception {	   
		String realFolder = null;
		JSONObject json = new JSONObject();
		UUID uuid = UUID.randomUUID();
		// ���ε��� ���� �̸�
		String org_filename = file.getOriginalFilename();
		String str_filename = uuid.toString() + org_filename;
		logger.info("���� ���ϸ� : {}",org_filename); //.........photo.jpg
		logger.info("������ ���ϸ� : {}",str_filename); //ad340234fsdfbdfvfd0924309..........photo.jpg
		if(goods_id != null) {  //�����ڰ� å �̹��� ���� ���ε��
			byte[] data = file.getBytes();
			FileOutputStream fos = new FileOutputStream("C:\\SpringShoppingmall\\workplace\\ShoppingApp\\src\\main\\webapp\\goodsimgUpload\\" +  str_filename); //��Ŭ���� ���� goodsimgUpload ���� �ȿ� ������ ����,���߽� ���� �ý��� ���� ���
			//FileOutputStream fos = new FileOutputStream("/opt/tomcat/webapps/ROOT/upload/" +  str_filename);  -> aws ���� �ý��� ���� ���
			fos.write(data);
			fos.close();
			logger.info("bookimagefile str_filename : {}",str_filename);
			File multitofile = convertfrommultiparttofile(str_filename,"book");
			awsserviceimpl.s3FileUpload(multitofile,"book");  //s3 ��Ŷ�� ���� ���ε� -> ���߿� url�� �����Ͽ� DB�� url�� ����.
			json.put("url","https://shoppingmallbucket.s3.ap-northeast-2.amazonaws.com/bookimage/" + str_filename);
			return json.toJSONString();
		} else if(reviewimgflag != null) {
			try {
				byte[] data = file.getBytes();
				FileOutputStream fos = new FileOutputStream("C:\\SpringShoppingmall\\workplace\\ShoppingApp\\src\\main\\webapp\\reviewUpload\\" +  str_filename); //��Ŭ���� ���� boardUpload ���� �ȿ� ������ ����
				//FileOutputStream fos = new FileOutputStream("/opt/tomcat/webapps/ROOT/boardupload/" +  str_filename);  -> aws ���� �ý���
				fos.write(data);
				fos.close();
				logger.info("reivewimage str_filename : {}",str_filename);
				File multitofile = convertfrommultiparttofile(str_filename,"review");
				awsserviceimpl.s3FileUpload(multitofile,"review");  //s3 ��Ŷ�� ���� ���ε� -> ���߿� url�� �����Ͽ� DB�� url�� ����.
				json.put("url","https://shoppingmallbucket.s3.ap-northeast-2.amazonaws.com/reviewimage/" + str_filename);
				return json.toString();
			} catch(Exception e) {
				logger.info("���� �̹��� ���� ���ε� ����");
				return null;
			}
		}
		else {  //�Խ��� �̹��� ���ε��
			byte[] data = file.getBytes();
			FileOutputStream fos = new FileOutputStream("C:\\SpringShoppingmall\\workplace\\ShoppingApp\\src\\main\\webapp\\boardUpload\\" +  str_filename); //��Ŭ���� ���� boardUpload ���� �ȿ� ������ ����
			//FileOutputStream fos = new FileOutputStream("/opt/tomcat/webapps/ROOT/boardupload/" +  str_filename);  -> aws ���� �ý���
			fos.write(data);
			fos.close();
			logger.info("boardfile str_filename : {}",str_filename);
			File multitofile = convertfrommultiparttofile(str_filename,"board");
			awsserviceimpl.s3FileUpload(multitofile,"board");  //s3 ��Ŷ�� ���� ���ε� -> ���߿� url�� �����Ͽ� DB�� url�� ����.
			json.put("url","https://shoppingmallbucket.s3.ap-northeast-2.amazonaws.com/boardimage/" + str_filename);
			return json.toJSONString();
		}
	}
	
	private File convertfrommultiparttofile(String filename,String whatupload) throws Exception {
		if(whatupload.equals("book")) {
			File file = new File("C:\\SpringShoppingmall\\workplace\\ShoppingApp\\src\\main\\webapp\\goodsimgUpload\\" + filename);
			return file;
		} else {
			File file = new File("C:\\SpringShoppingmall\\workplace\\ShoppingApp\\src\\main\\webapp\\reviewUpload\\" + filename);
			return file;
		}
	}
	
	@PostMapping("/usecoupon")
	public Integer usecoupon(@RequestParam String cnumber){
		Integer data = couponserviceimpl.usecoupon(cnumber);
	    return data;
	}
	
	@PostMapping("/makecoupon")  //����ڰ� ������ �ޱ�
	public Integer makecoupon(@RequestParam String Id){
		return couponserviceimpl.receivecoupon(Id);
	}
	 
	@PostMapping("/deleteallshoppingcart")
	public void deleteallshoppingmall(@RequestParam String Id){
		shoppingbasketimpl.deleteall(Id);
	}
	 
	@GetMapping("/commentList")
	public List<Reply> commentList(@RequestParam String gId){
		return replyserviceimpl.commentlist(gId);
	}
	 
	@GetMapping("/addComment")
	public boolean addComment(@RequestParam String reply,@RequestParam String gId,@RequestParam String user_id,
			@RequestParam(required = false) Integer reviewpoint){
		return replyserviceimpl.addComment(gId,user_id,reply);
	}
	
	@GetMapping("/contentreplymodify")
	public void contentreplymodify(@RequestParam String gId,@RequestParam String rId,@RequestParam String content,  //gId : å�� �̸�,rId : ���� ����� ��ȣ,content : ���� ����� ����
			HttpServletRequest request,HttpServletResponse response){
		String strreferer = request.getHeader("referer");
		logger.info("referer:"+strreferer);
		if(strreferer == null){
			try {
			response.setContentType("text/html; charset=UTF-8");
			response.sendRedirect("https://localhost:8443/shoppingmall/home");
			//response.sendRedirect("https://www.forallshoppingmall.com/shoppingmall/home");
			//PrintWriter writer = response.getWriter();
			//writer.print("<!DOCTYPE html><html><head><title>����������</title></head><body><h1 style = 'text-align:center'>ErrorPage</h1><script>location.href='https://localhost:8443/shoppingmall/home';</script></body></html>");
			}catch(Exception e){
				e.printStackTrace();
			}
			return;
		}
		replyserviceimpl.contentreplymodify(gId,rId,content);
	}
	
	@GetMapping("/contentreplydelete")
	public void contentreplydelete(@RequestParam String gId,@RequestParam String rId,HttpServletRequest request,
			HttpServletResponse response){  //gId : å�� �̸�,rId : ���� ����� ��ȣ
		String strreferer = request.getHeader("referer");
		logger.info("referer: {}",strreferer);
		if(strreferer == null){
			try {
				response.setContentType("text/html; charset=UTF-8");
				response.sendRedirect("https://localhost:8443/shoppingmall/home");
				//response.sendRedirect("https://www.forallshoppingmall.com/shoppingmall/home");
				//PrintWriter writer = response.getWriter();
				//writer.print("<!DOCTYPE html><html><head><title>����������</title></head><body><h1 style = 'text-align:center'>ErrorPage</h1><script>location.href='https://localhost:8443/shoppingmall/home';</script></body></html>");
			}catch(Exception e){
				e.printStackTrace();
			}
			return;
		}
		logger.info("deletegId(å�̸�) : {}",gId);
		logger.info("deleterId(���� ��� ��ȣ) : {}",rId);
		replyserviceimpl.contentreplydelete(gId,rId);
	}
	
	@PostMapping("/usedcouponcheck")  //������ �̹� ���� �������� Ȯ��
	public int usedcouponcheck(@RequestParam String cnumber){
		return couponserviceimpl.usedcouponcheckmethod(cnumber);
	}
	
	@PostMapping("/productrecommend")  //å�� ��õ�ϴ� ��û�� ���� ó��
	public int productrecommend(Bookrecommend recommend,HttpSession session) {
		String userid = (String)session.getAttribute("Userid");
		recommend.setUserid(userid);
		return productserviceimpl.bookrecommend(recommend,userid);
	}
	
	@PostMapping("/getnoticecoupon")
	public int getnoticecoupon(@RequestParam String id){
		return couponserviceimpl.getcouponscountbyuserId(id);
	}
	
	@PostMapping(value = "/addreview",produces = "application/text; charset=utf8")
	public String addreview(@RequestBody HashMap<String,Object> map) {
		int reviewRating = (Integer)map.get("reviewRating");
		String reviewimgurl = (String)map.get("reviewimgurl");
		String user_id = (String)map.get("user_id");
		String reviewcontent = (String)map.get("reviewContent");
		int tag = Integer.valueOf((String)map.get("feelTagRating"));
		logger.info("tag : {}",tag);
		logger.info("reviewcontent : {}",reviewcontent);
		String bookname = (String)map.get("bookname");
		Reply userreview = new Reply();
		userreview.setContent(reviewcontent);
		userreview.setReviewpoint(reviewRating);
		userreview.setUser_id(user_id);
		userreview.setImgfileurl(reviewimgurl);
		userreview.setGid(bookname);
		userreview.setTag(tag);
		if(replyserviceimpl.addreview(userreview)) {
			return "���� ��� ���ε� ����";
		} else {
			return "���� ��� ���ε� ����";
		}
	}
	
	@PostMapping("/addreviewreply")
	public void addreviewreply(@RequestBody HashMap<String,Object> map) {
		String user_id = (String)map.get("user_id");
		String bookname = (String)map.get("bookname");
		//String reviewReply = (String)map.get("reviewReply");
		String reviewContent = (String)map.get("reviewContent");
		int rid = (Integer)map.get("rid");  //addreviewreply�� rid�� �Ѱ��ش���,Reply ��ü�� ã�Ƽ� ReviewReply ��ü rid�� �־��ش�..
		logger.info("content : {}",reviewContent);
		ReviewReply userreview = new ReviewReply();
		userreview.setUser_id(user_id);
		userreview.setBookname(bookname);
		//userreview.setRid(rid);
		userreview.setContent(reviewContent);
		replyserviceimpl.addreviewreply(userreview,rid);  //������ �ڵ� �κ�
	}
	
	@PostMapping(value = "/reviewmodify",produces = "application/text; charset=utf8")
	public String reviewmodify(@RequestParam String content,@RequestParam int reviewid) {
		String modifycontent = content;
		replyserviceimpl.reviewmodify(content,reviewid);
		return modifycontent;
	}
	
	@PostMapping(value = "/reviewdelete")
	public void reviewdelete(@RequestParam int reviewid,HttpServletRequest request,HttpServletResponse response){
		String referer = (String)request.getHeader("REFERER");
		logger.info("referer : {}",referer);
		try {
			response.sendRedirect("https://localhost:8443/shoppingmall/home");
		} catch(Exception e) {
			e.printStackTrace();
		}
		replyserviceimpl.reviewdelete(reviewid);
	}
	
	@PostMapping("/reviewreplydelete")
	public void reviewreplydelete(@RequestParam int reviewreplyid,HttpServletRequest request,HttpServletResponse response) {
		/*String referer = (String)request.getHeader("REFERER");
		logger.info("referer : {}",referer);
		try {
			response.sendRedirect("https://localhost:8443/shoppingmall/home");
		} catch(Exception e) {
			e.printStackTrace();
		}*/
		replyserviceimpl.reviewreplydelete(reviewreplyid);
	}
	
	@PostMapping("/reviewrecommend")
	public void reviewrecommend(@RequestParam int reviewid,@RequestParam String userid) {
		replyserviceimpl.reviewrecommend(reviewid,userid);
	}
	
	@PostMapping("/reviewreplyrecommend")
	public void reviewreplyrecommend(@RequestParam int reviewreplyid,@RequestParam String userid) {
		replyserviceimpl.reviewreplyrecommend(reviewreplyid,userid);
	}

	@PostMapping("/reviewrecommendcheck")
	public boolean reviewrecommendcheck(@RequestParam int reviewid,@RequestParam String userid) {
		return replyserviceimpl.reviewrecommendcheck(reviewid,userid);
	}
	
	@PostMapping("/reviewreplyrecommendcheck")
	public boolean reviewreplyrecommendcheck(@RequestParam int reviewreplyid,@RequestParam String userid) {
		return replyserviceimpl.reviewreplyrecommendcheck(reviewreplyid,userid);
	}
}
