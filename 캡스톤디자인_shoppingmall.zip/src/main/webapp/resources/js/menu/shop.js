function makecoupon(Id)
{
	$.ajax({
		url : "/shoppingmall/makecoupon",
		data : {"Id" : Id},
		method : "POST",
		success : function(data){
			if(data == 0)
			{
				alert('받을 수 있는 쿠폰이 없습니다.');
			}
			else if(data == 1)
			{
				alert('쿠폰을 모두 받으셨습니다.');
			}
		},
		error : function(err){
			alert("에러 발생");
		}
	});
}