window.onload = function(){
	$.ajax({
		url : "/shoppingmall/getnoticecoupon",
		data : {"id" : user},
		type : "post",
		success : function(data){
			if(data > 0){
				alert('받지 않은 쿠폰이 ' + data + '개 있습니다.쿠폰 받기를 통해 쿠폰을 받아주세요.');
			}
		},
		error : function(){
			console.log('에러 발생');
		}
	});
}

$(function(){
	$('#main_product_slide').slick({
		  pauseOnHover:true,
		  autoplay: true,
		  autoplaySpeed:3500,
		  arrows: true,
		  dots: true,
		  infinite: true,
		  speed: 300,
		  slidesToShow: 1,
		  slidesToScroll: 1,
		   responsive: [
				 	 {
				      breakpoint: 500,
				      settings: {
				    	  arrows: false					        
				      }
				    }
			]					 	 
	});
				
	$('.range-product-slider__scrollable').slick({
		  pauseOnHover:true,
		  autoplay: true,
		  autoplaySpeed:3500,
		  arrows: true,
		  dots: false,
		  infinite: true,
		  speed: 300,
		  slidesToShow: 4,
		  slidesToScroll: 4,	
		  
		  responsive: [
			 	 {
			      breakpoint: 1710,
			      settings: {
			        slidesToShow: 3,
			        slidesToScroll: 3,
			        infinite: true,
			        dots: false,
			        
			      }
			    },
		  
			  {
			      breakpoint: 1454,
			      settings: {
			        slidesToShow: 2,
			        slidesToScroll: 2,
			        infinite: true,
			        dots: false,
			        
			      }
			    },
	
			  {
			      breakpoint: 1124,
			      settings: {
			        slidesToShow: 1,
			        slidesToScroll: 1,
			        infinite: true,
			        dots: false,
			        
			      }
			    },
		 	
		   {
		      breakpoint: 1024,
		      settings: {
		        slidesToShow: 1,
		        slidesToScroll: 1,
		        infinite: true,
		        dots: false,
		        
		      }
		    },
		    
		    {
		         breakpoint: 991,
		         settings: {
		           slidesToShow: 1,
		           slidesToScroll: 1
		         }
		     },
		    
		       {
		         breakpoint: 758,
		         settings: {
		           slidesToShow: 2,
		           slidesToScroll: 2
		         }
		       },				     
		       {
		         breakpoint: 700,
		         settings: {
		           slidesToShow: 2,
		           slidesToScroll: 2
		         }
		       },
		     
		     {
		      breakpoint: 600,
		      settings: {
		        slidesToShow: 2,
		        slidesToScroll: 2
		      }
		    },
		 
		    {
		      breakpoint: 480,
		      settings: {
		        slidesToShow: 1,
		        slidesToScroll: 1
		      }
		    }
		    ,
		    
	     
		]
	
	});
	
});	


/*
var ws = new WebSocket("wss://localhost:8443/shoppingmall/echo");
ws.onopen = function(){
	console.log('웹 소켓 연결 성공');
}

ws.onmessage = function onMessage(msg){
	
}

ws.onclose = function onClose(evt) {
	console.log('웹 소켓 연결 끊김');
}
*/