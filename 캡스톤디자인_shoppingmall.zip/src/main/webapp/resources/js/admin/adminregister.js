		function moveurl(){
 			 if($("#bigclass").val() == "novel")
			 {
				location.href = "/shoppingmall/admin/registerForm?bigclass=novel";
			 } 
			 else if($("#bigclass").val() == "economy"){
				location.href = "/shoppingmall/admin/registerForm?bigclass=economy";
			 }
			 else if($("#bigclass").val() == "humanity"){
					location.href = "/shoppingmall/admin/registerForm?bigclass=humanity";
			 }
			 else if($("#bigclass").val() == "religion"){
					location.href = "/shoppingmall/admin/registerForm?bigclass=religion";
			 }
			 else if($("#bigclass").val() == "science"){
					location.href = "/shoppingmall/admin/registerForm?bigclass=science";
			 }
			 else if($("#bigclass").val() == "politics"){
					location.href = "/shoppingmall/admin/registerForm?bigclass=politics";
			 }
			 else if($("#bigclass").val() == "children"){
					location.href = "/shoppingmall/admin/registerForm?bigclass=children";
			 }
			 else if($("#bigclass").val() == "computer"){
					location.href = "/shoppingmall/admin/registerForm?bigclass=computer";
			 }
			 else if($("#bigclass").val() == "cook"){
					location.href = "/shoppingmall/admin/registerForm?bigclass=cook";
			 }
			 else if($("#bigclass").val() == "textbook"){
					location.href = "/shoppingmall/admin/registerForm?bigclass=textbook";
			 }
			 else if($("#bigclass").val() == "foreign"){
					location.href = "/shoppingmall/admin/registerForm?bigclass=foreign";
			 }
			 else if($("#bigclass").val() == "cartoon"){
					location.href = "/shoppingmall/admin/registerForm?bigclass=cartoon";
			 }
			 else if($("#bigclass").val() == "magazine"){
					location.href = "/shoppingmall/admin/registerForm?bigclass=magazine";
			 }
 		}

		function registerfile(){
		   var formData = new FormData();
	       formData.append('file',$("#imgfile")[0].files[0]);
	       formData.append('goods_id',1);
		   $.ajax({
			data: formData,
		  	method: 'post',
		  	url: '/shoppingmall/upload',
		  	cache: false,
		  	contentType: false,
		  	processData: false,
		  	enctype: 'multipart/form-data',
		  	success: function(data) //url; 
		  	{
		  		var obj = JSON.parse(data);
		  		alert(obj.url)
		  		var img = document.createElement("img");
		      	img.src = obj.url;
		      	img.setAttribute("width","550px");
		  		img.setAttribute("height","550px");
		  		document.getElementById("loadimg").appendChild(img);
		  		$("#imgthumbnail").val(obj.url);
		  	},
		  	error:function(data)
		  	{
		  		console.log(data);
		  		alert('error');
		  	}
		  });
		}
		window.onload = function(){
			document.getElementById("imgfile").addEventListener("change",registerfile);
		}
		function makecoupon(Id)
		{
			$.ajax({
				url : "/shoppingmall/makecoupon",
				data : {"Id" : Id},
				method : "POST",
				success : function(data){
					if(data == 0)
					{
						alert('받을 수 있는 쿠폰이 없습니다.');
					}
					else if(data == 1)
					{
						alert('쿠폰을 모두 받으셨습니다.');
					}
				},
				error : function(err){
					alert("에러 발생");
				}
			});
		}