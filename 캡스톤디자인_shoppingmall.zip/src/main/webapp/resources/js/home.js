function makecoupon(Id){
    		$.ajax({
    			url : "/shoppingmall/makecoupon",
    			data : {"Id" : Id},
    			method : "POST",
    			success : function(data){
    				if(data == 0)
					{
    					alert('받을 수 있는 쿠폰이 없습니다.');
					}
    				else if(data == 1)
    				{
    					alert('쿠폰을 모두 받으셨습니다.');
    				}
    			},
    			error:function(request,status,error){
    		        alert("code:"+request.status+"\n"+"message:"+request.responseText+"\n"+"error:"+error);
    		       }
    		});
}